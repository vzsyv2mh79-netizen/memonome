"""Run generated web apps in an isolated browser with no external network.
Only declarative UI steps are accepted, never generated Python/shell code.
"""
import json
import mimetypes
import sys
from pathlib import Path
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright


def verify(root):
    root = Path(root).resolve()
    plan = json.loads((root / 'checks.json').read_text())
    tests = plan.get('tests', [])
    if not isinstance(tests, list) or not 1 <= len(tests) <= 12:
        raise ValueError('操作テストが必要です（1〜12件）。')
    errors, results = [], []
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, chromium_sandbox=True)
        try:
            context = browser.new_context(viewport={'width':390,'height':844}, service_workers='block', accept_downloads=False)
            def route(req):
                url = urlparse(req.request.url)
                name = url.path.lstrip('/') or 'index.html'
                target = (root / name).resolve()
                if url.scheme != 'https' or url.netloc != 'memonome.invalid' or not target.is_relative_to(root) or target.is_symlink() or not target.is_file() or target.suffix not in ('.html','.css','.js','.svg'):
                    errors.append('禁止された外部通信または存在しないファイル: ' + url.path[:120])
                    req.abort(); return
                req.fulfill(body=target.read_bytes(), content_type=mimetypes.guess_type(name)[0] or 'text/plain', headers={'Content-Security-Policy':"default-src 'self' data:; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'"})
            context.route('**/*', route)
            context.route_web_socket('**/*', lambda ws: ws.close())
            for test in tests:
                page = context.new_page()
                page.set_default_timeout(3000)
                page.on('pageerror', lambda e: errors.append(str(e)[:1000]))
                page.on('console', lambda msg: errors.append(msg.text[:1000]) if msg.type == 'error' else None)
                page.on('dialog', lambda d: d.dismiss())
                try:
                    context.clear_cookies()
                    page.goto('https://memonome.invalid/', timeout=10000)
                    page.evaluate('localStorage.clear(); sessionStorage.clear()')
                    page.reload()
                    if not page.locator('body').inner_text().strip():
                        raise ValueError('画面が空です。')
                    steps = test.get('steps', [])
                    if not 1 <= len(steps) <= 30 or not any(s.get('action','').startswith('expect_') for s in steps):
                        raise ValueError('各テストに結果の確認が必要です。')
                    for step in steps:
                        action = step.get('action')
                        loc = page.locator(step.get('selector', 'body'))
                        if action == 'click': loc.click()
                        elif action == 'fill': loc.fill(str(step['value']))
                        elif action == 'select': loc.select_option(str(step['value']))
                        elif action == 'check': loc.check()
                        elif action == 'reload': page.reload()
                        elif action == 'expect_text':
                            from playwright.sync_api import expect
                            expect(loc).to_contain_text(str(step['value']), timeout=3000)
                        elif action == 'expect_value':
                            from playwright.sync_api import expect
                            expect(loc).to_have_value(str(step['value']), timeout=3000)
                        elif action == 'expect_count':
                            from playwright.sync_api import expect
                            expect(loc).to_have_count(int(step['value']), timeout=3000)
                        elif action == 'expect_visible':
                            from playwright.sync_api import expect
                            expect(loc).to_be_visible(timeout=3000)
                        else: raise ValueError('未対応のテスト操作です。')
                    results.append({'name':str(test.get('name','操作確認'))[:100], 'passed':True})
                    page.screenshot(path=str(root/'preview.png'))
                except Exception as e:
                    results.append({'name':str(test.get('name','操作確認'))[:100], 'passed':False,'error':str(e)[:2000]})
                finally: page.close()
        finally: browser.close()
    return {'passed': bool(results) and all(t['passed'] for t in results) and not errors,'tests':results,'errors':errors[:20]}

if __name__ == '__main__':
    try: result = verify(sys.argv[1])
    except Exception as e: result = {'passed':False,'tests':[],'errors':[str(e)[:2000]]}
    Path(sys.argv[2]).write_text(json.dumps(result,ensure_ascii=False))
