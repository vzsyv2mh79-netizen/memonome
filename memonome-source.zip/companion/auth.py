"""Official Sign in with ChatGPT. No API keys or Codex credential reuse."""
import base64
import hashlib
import json
import os
import secrets
import time
import uuid
from pathlib import Path
from urllib.parse import urlencode
import jwt
import requests

AUTH = 'https://auth.openai.com'
RESOURCE = 'https://api.openai.com/v1'
SCOPES = 'openid profile email offline_access resource.invoke chatgpt.tokens.use.direct'


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temporary = path.with_name(path.name + '.' + secrets.token_hex(8) + '.tmp')
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, 'w') as f:
            json.dump(value, f, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


class Auth:
    def __init__(self, root):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        os.chmod(self.root, 0o700)
        self.file = self.root / 'credentials.json'
        self.record = json.loads(self.file.read_text()) if self.file.exists() else {}
        hostfile = self.root / 'host.json'
        if not hostfile.exists():
            atomic_json(hostfile, {'id': 'urn:uuid:' + str(uuid.uuid4())})
        self.host = json.loads(hostfile.read_text())['id']
        self.pending = None

    def begin(self, redirect):
        verifier = secrets.token_urlsafe(48)
        self.pending = dict(state=secrets.token_urlsafe(32), nonce=secrets.token_urlsafe(32),
                            verifier=verifier, redirect=redirect, created=time.time())
        p = dict(client_id=self.record.get('client_id', 'dynamic_agent_client'),
                 ext_agent_host_id=self.host, response_type='code', redirect_uri=redirect,
                 scope=SCOPES, resource=RESOURCE, state=self.pending['state'],
                 nonce=self.pending['nonce'], code_challenge_method='S256',
                 code_challenge=base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b'=').decode())
        if not self.record.get('client_id'):
            p['agent_name_hint'] = 'Memonome'
        return AUTH + '/api/accounts/authorize?' + urlencode(p)

    def finish(self, query):
        p, self.pending = self.pending, None
        if not p or time.time() - p['created'] > 600 or not secrets.compare_digest(query.get('state', ''), p['state']):
            raise ValueError('ログインの確認に失敗しました。もう一度接続してください。')
        if query.get('error'):
            raise ValueError('ログインはキャンセルされました。')
        client = query.get('client_id', self.record.get('client_id'))
        if not client or client == 'dynamic_agent_client' or (self.record.get('client_id') and client != self.record['client_id']):
            raise ValueError('登録先が一致しません。')
        r = requests.post(AUTH + '/api/accounts/oauth/token', data=dict(
            grant_type='authorization_code', client_id=client, code=query.get('code', ''),
            code_verifier=p['verifier'], redirect_uri=p['redirect'], resource=RESOURCE), timeout=30)
        r.raise_for_status()
        data = r.json()
        key = jwt.PyJWKClient(AUTH + '/.well-known/jwks.json').get_signing_key_from_jwt(data['id_token'])
        claims = jwt.decode(data['id_token'], key.key, algorithms=['RS256'], audience=client,
                            issuer=AUTH, options={'require': ['exp', 'iss', 'aud', 'sub', 'nonce']})
        if not secrets.compare_digest(claims['nonce'], p['nonce']):
            raise ValueError('ログインの確認に失敗しました。')
        if self.record.get('subject') and self.record['subject'] != claims['sub']:
            raise ValueError('接続するアカウントが変わっています。先に接続解除してください。')
        if 'chatgpt.tokens.use.direct' not in data.get('scope', '').split():
            raise ValueError('ChatGPT利用枠の使用が許可されていません。')
        self.record = dict(data, client_id=client, subject=claims['sub'], email=claims.get('email', ''),
                           expires_at=time.time() + data['expires_in'], credits_disabled_confirmed=False)
        atomic_json(self.file, self.record)

    def token(self):
        if not self.record.get('access_token') or not self.record.get('credits_disabled_confirmed'):
            raise ValueError('ChatGPT接続と追加クレジット無効の確認が必要です。')
        if self.record['expires_at'] < time.time() + 60:
            r = requests.post(AUTH + '/api/accounts/oauth/token', data=dict(
                grant_type='refresh_token', client_id=self.record['client_id'],
                refresh_token=self.record['refresh_token'], resource=RESOURCE), timeout=30)
            r.raise_for_status()
            data = r.json()
            scopes = data.get('scope', self.record.get('scope', '')).split()
            if 'chatgpt.tokens.use.direct' not in scopes:
                raise ValueError('利用枠の権限が失われました。')
            self.record.update(data)
            self.record['expires_at'] = time.time() + data['expires_in']
            atomic_json(self.file, self.record)
        return self.record['access_token']
