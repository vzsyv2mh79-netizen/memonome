"""Local native build/test/install. Fixed commands only; no uploads or purchasing."""
import hashlib,json,os,signal,subprocess,time,uuid
from pathlib import Path
from auth import atomic_json
from native_project import create_project

class NativeCancelled(Exception): pass

def run(args, root, label, cancelled, timeout=900):
    logfile=root/(label+'.log')
    with logfile.open('w') as log:
        p=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env={k:v for k,v in os.environ.items() if k in ('HOME','PATH','TMPDIR','LANG','DEVELOPER_DIR')})
        start=time.monotonic()
        try:
            while p.poll() is None:
                if cancelled(): raise NativeCancelled('停止しました。')
                if time.monotonic()-start>timeout: raise TimeoutError('iPhoneアプリのビルド・確認が時間内に終わりませんでした。')
                time.sleep(1)
        finally:
            if p.poll() is None:
                os.killpg(p.pid,signal.SIGTERM)
                try:p.wait(timeout=10)
                except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    output=logfile.read_text(errors='replace')
    return p.returncode, output[-18000:]

def verify_and_install(project, saved, request, config, status, cancelled):
    root=Path(project);root.mkdir(parents=True,exist_ok=True)
    suffix=uuid.UUID(request['id']).hex
    bundle='jp.shizuie.memonome.preview.p'+suffix
    scheme='memonome-preview-'+suffix
    digest=hashlib.sha256(json.dumps(saved,sort_keys=True).encode()).hexdigest()
    recordfile=root/'native-progress.json'
    record=json.loads(recordfile.read_text()) if recordfile.exists() else {}
    if record.get('hash') != digest:record={'hash':digest}
    source=saved['NativeApp.swift'];checks=json.loads(saved['ios-checks.json'])
    create_project(root,source,checks,bundle,scheme)
    def checkpoint(**kw):record.update(kw);atomic_json(recordfile,record)
    xcode=['/usr/bin/xcodebuild','-project',str(root/'Preview.xcodeproj'),'-scheme','Preview','-configuration','Debug','-jobs','2','ONLY_ACTIVE_ARCH=YES','-derivedDataPath',str(root/'build')]
    if not record.get('tested'):
        status('running',55,'iPhoneアプリをビルドし、シミュレータで操作・保存を確認中です。')
        sim=str(uuid.UUID(config['simulator'])).upper()
        code,output=run(xcode+['-destination','platform=iOS Simulator,id='+sim,'-parallel-testing-enabled','NO','-maximum-concurrent-test-simulator-destinations','1','CODE_SIGNING_ALLOWED=NO','test'],root,'simulator-test',cancelled,1200)
        if code!=0:
            phase = 'environment' if any(marker in output for marker in ('Unable to find a destination', 'Unable to find a device', 'Failed to boot', 'CoreSimulatorService connection', 'Timed out waiting', 'Failed to establish communication')) else 'test'
            return {'phase':phase,'passed':False,'diagnostic':output}
        checkpoint(tested=True)
    if not record.get('built'):
        status('running',75,'操作テストに合格しました。接続したiPhone向けに署名してビルド中です。')
        team=config['team']
        if not team.isalnum() or len(team)!=10:raise ValueError('Macの開発チーム設定を確認してください。')
        code,output=run(xcode+['-destination','generic/platform=iOS','DEVELOPMENT_TEAM='+team,'-allowProvisioningUpdates','build'],root,'device-build',cancelled)
        if code!=0:return {'phase':'signing','passed':False,'diagnostic':output}
        checkpoint(built=True)
    if not record.get('installed'):
        status('running',85,'iPhoneへ試作品をインストール中です。接続とロック解除が必要です。')
        device=config['device']
        if not device or any(c not in '0123456789abcdefABCDEF-' for c in device):raise ValueError('iPhoneの接続先設定を確認してください。')
        code,output=run(['/usr/bin/xcrun','devicectl','device','install','app','--device',device,str(root/'build/Build/Products/Debug-iphoneos/Preview.app')],root,'device-install',cancelled,90)
        if code!=0:return {'phase':'device','passed':False,'diagnostic':output}
        checkpoint(installed=True)
    return {'passed':True,'phase':'review','previewURL':scheme+'://','bundle':bundle,'tests':[t.get('name','操作確認') for t in checks['tests']]}
