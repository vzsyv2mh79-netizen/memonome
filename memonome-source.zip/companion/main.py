#!/usr/bin/env python3
"""Run locally: python main.py --sync /path/to/your/private/sync/folder"""
import argparse
import fcntl
import html
import json
import secrets
import threading
import time
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import parse_qs, urlparse
import requests
from auth import Auth, atomic_json, RESOURCE
from worker import Worker


def serve(sync, local, port):
    sync, local = Path(sync).expanduser().resolve(), Path(local).expanduser().resolve()
    if local.is_relative_to(sync) or sync.is_relative_to(local):
        raise ValueError('認証保存先と同期フォルダは別の場所にしてください。')
    sync.mkdir(parents=True, exist_ok=True)
    local.mkdir(parents=True, exist_ok=True, mode=0o700)
    lockfile = (local / 'lock').open('w')
    fcntl.flock(lockfile, fcntl.LOCK_EX | fcntl.LOCK_NB)
    auth = Auth(local)
    worker = Worker(auth, sync, local)
    csrf = secrets.token_urlsafe(32)
    models = []
    message = '接続済みです。モデルを選んで自動処理を開始してください。' if auth.record.get('access_token') else '初めにChatGPTを接続してください。'
    stop = threading.Event()
    def background():
        while not stop.wait(3):
            try:
                worker.tick()
            except Exception:
                worker.running = False
                worker.ledger['blocked'] = True
                worker.persist()
    thread = threading.Thread(target=background, daemon=True)
    thread.start()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass  # OAuth callback codes and request parameters must never be logged.

        def send(self, body, status=200):
            data = body.encode()
            self.send_response(status)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'; form-action 'self' https://auth.openai.com; frame-ancestors 'none'; base-uri 'none'")
            self.send_header('Referrer-Policy', 'no-referrer')
            self.end_headers()
            self.wfile.write(data)

        def valid_host(self):
            return self.headers.get('Host') == f'127.0.0.1:{self.server.server_port}'

        def do_GET(self):
            nonlocal message
            if not self.valid_host():
                return self.send('接続先が一致しません。', 403)
            path = urlparse(self.path)
            if path.path == '/auth/callback':
                try:
                    auth.finish({k: v[0] for k, v in parse_qs(path.query).items()})
                    message = 'ChatGPTに接続しました。対象のAI処理はあなたの契約枠を使います。次に追加クレジットを無効にしてください。'
                except Exception:
                    message = 'ログインを完了できませんでした。権限と接続を確認して、再度ログインしてください。'
                self.send_response(303)
                self.send_header('Location', '/')
                self.end_headers()
                return
            if path.path != '/':
                return self.send('Not found', 404)
            options = ''.join(f'<option value="{html.escape(m["slug"], quote=True)}" {"selected" if m["slug"] == worker.model else ""}>{html.escape(m["display_name"])}</option>' for m in models)
            connected = bool(auth.record.get('access_token'))
            body = f'''<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>芽メモ · Mac連携</title>
<style>body{{font:17px system-ui;max-width:640px;margin:40px auto;padding:20px;background:#101d18;color:#e7f3eb}}section{{background:#203229;padding:20px;border-radius:18px;margin:18px 0}}button,select{{font:inherit;padding:12px;border-radius:12px;border:0;margin:8px 0}}button{{background:#b5efbf;color:#14221a}}a{{color:#b5efbf}}small{{display:block;line-height:1.8}}label{{display:block;margin:15px 0}}</style>
<h1>🌱 芽メモ · Mac連携</h1><p>{html.escape(message)}</p>
<section><strong>{'ChatGPT接続済み' if connected else '未接続'}</strong><p>{html.escape(auth.record.get('email', ''))}</p>
<form method="post"><input type="hidden" name="csrf" value="{csrf}"><button name="action" value="login">Continue with ChatGPT</button></form>
<a href="https://chatgpt.com/settings/usage" target="_blank" rel="noreferrer">ChatGPTの利用枠・追加クレジット設定を開く</a></section>
<section><h2>追加料金を使わない</h2><small>ChatGPT設定でMemonomeの「契約枠を超えた後にクレジットを使用」をオフにしてください。アプリからその設定を読み取る公式手段は確認できていません。設定を変更したらMac連携を停止してください。APIキー・有料APIへの切り替え・クレジット購入は行いません。</small>
<form method="post"><input type="hidden" name="csrf" value="{csrf}"><label><input type="checkbox" name="confirmed" required> 追加クレジットの使用をオフにした</label><button name="action" value="models" {'disabled' if not connected else ''}>確認してモデルを読み込む</button></form></section>
<section><h2>{'開発中・待機中' if worker.running and not worker.ledger['blocked'] else '停止中'}</h2><p>1日最大3回・同期フォルダ5MBまで。エラー時は停止。現在の版は静的Webアプリの試作品を作成します。</p>
<form method="post"><input type="hidden" name="csrf" value="{csrf}"><select name="model">{options}</select><button name="action" value="start" {'disabled' if not models else ''}>自動処理を開始</button><button name="action" value="stop">停止</button></form>
<small>同期フォルダ：{html.escape(str(sync))}<br>Macの電源と同期サービスの接続が必要です。同期サービスの容量不足・遅延は芽メモから検出できない場合があります。容量追加の購入は行いません。共有フォルダは他人と共有しないでください。</small></section>
<p>公開・支払い・シェルコマンド実行は自動化しません。生成ファイルは未検証の試作品です。</p></html>'''
            self.send(body)

        def do_POST(self):
            nonlocal message, models
            if not self.valid_host() or self.headers.get('Origin') not in (None, 'null', f'http://127.0.0.1:{self.server.server_port}'):
                return self.send('許可されていない操作です。', 403)
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length < 4096:
                return self.send('入力が大きすぎます。', 400)
            data = {k: v[0] for k, v in parse_qs(self.rfile.read(length).decode()).items()}
            if not secrets.compare_digest(data.get('csrf', ''), csrf):
                return self.send('操作の確認に失敗しました。', 403)
            action = data.get('action')
            try:
                if action == 'stop':
                    worker.running = False
                    message = '停止しました。実行中の場合は、次の応答または通信タイムアウト時に止まります。'
                elif action == 'login':
                    if worker.running:
                        raise ValueError('先に自動処理を停止してください。')
                    location = auth.begin(f'http://127.0.0.1:{self.server.server_port}/auth/callback')
                    self.send_response(303)
                    self.send_header('Location', location)
                    self.end_headers()
                    return
                elif action == 'models':
                    if worker.running or data.get('confirmed') != 'on':
                        raise ValueError('停止中に設定を確認してください。')
                    auth.record['credits_disabled_confirmed'] = True
                    atomic_json(auth.file, auth.record)
                    r = requests.get(RESOURCE + '/models', headers={'Authorization': 'Bearer ' + auth.token()}, timeout=30)
                    r.raise_for_status()
                    models = [m for m in r.json()['models'] if m.get('visibility') == 'list']
                    message = '本人の利用可能モデルを取得しました。'
                elif action == 'start':
                    if worker.running:
                        raise ValueError('すでに動作中です。設定変更は停止してから行ってください。')
                    if data.get('model') not in [m['slug'] for m in models] or not auth.record.get('credits_disabled_confirmed'):
                        raise ValueError('接続と追加クレジット無効の確認が必要です。')
                    worker.model = data['model']
                    worker.ledger['blocked'] = False
                    worker.persist()
                    worker.running = True
                    message = 'メモを待っています。iPhoneで同じ同期フォルダを選び、AIにおまかせを押してください。'
            except Exception as e:
                worker.running = False
                message = str(e) if isinstance(e, ValueError) else '接続に失敗しました。処理を停止しています。'
            self.send_response(303)
            self.send_header('Location', '/')
            self.end_headers()

    server = HTTPServer(('127.0.0.1', port), Handler)
    print(f'芽メモ Mac連携: http://127.0.0.1:{server.server_port}/', flush=True)
    try:
        server.serve_forever()
    finally:
        stop.set()
        worker.running = False
        server.server_close()
        lockfile.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--sync', required=True, help='自分専用の同期フォルダ')
    parser.add_argument('--local', default=str(Path.home() / 'Library/Application Support/Memonome'))
    parser.add_argument('--port', type=int, default=8766)
    args = parser.parse_args()
    serve(args.sync, args.local, args.port)
