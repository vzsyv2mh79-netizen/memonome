"""Trusted Xcode project and UI-test generation. Model supplies Swift and JSON, never build scripts."""
import json
import plistlib
from pathlib import Path
from xml.sax.saxutils import escape


def test_source(plan):
    tests = plan.get('tests', [])
    if not isinstance(tests,list) or not 1 <= len(tests) <= 12: raise ValueError('操作テストは1〜12件必要です。')
    lines=['import XCTest','final class AppChecks: XCTestCase {']
    q=lambda x:json.dumps(str(x),ensure_ascii=False)
    for i,test in enumerate(tests):
        steps=test.get('steps',[])
        if not 1 <= len(steps) <= 30 or not any(s.get('action','').startswith('expect_') for s in steps): raise ValueError('各操作テストには結果の確認が必要です。')
        lines += [f'func testCase{i:02}() throws {{','continueAfterFailure = false','let app = XCUIApplication()','app.launchArguments = ["--ui-testing-reset"]','app.launch()','app.launchArguments = []']
        for step in steps:
            action=step.get('action');id=q(step.get('id',''));value=q(step.get('value',''))
            target=f'app.descendants(matching: .any).matching(identifier: {id}).firstMatch'
            if action=='tap': lines += [f'XCTAssertTrue({target}.waitForExistence(timeout: 5))', f'{target}.tap()']
            elif action=='type': lines += [f'{target}.tap()',f'{target}.typeText({value})']
            elif action=='relaunch': lines += ['app.terminate()','app.launch()']
            elif action=='expect_label': lines += [f'XCTAssertTrue({target}.waitForExistence(timeout: 5))',f'XCTAssertEqual({target}.label, {value})']
            elif action=='expect_value': lines += [f'XCTAssertTrue({target}.waitForExistence(timeout: 5))',f'XCTAssertEqual({target}.value as? String, {value})']
            elif action=='expect_exists': lines += [f'XCTAssertTrue({target}.waitForExistence(timeout: 5))']
            else: raise ValueError('未対応のiPhoneテスト操作です。')
        lines+=['let shot = XCTAttachment(screenshot: app.screenshot())','shot.lifetime = .keepAlways','add(shot)','}']
    return '\n'.join(lines+['}'])


def create_project(root, source, checks, bundle, scheme):
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    (root/'NativeApp.swift').write_text(source)
    (root/'AppChecks.swift').write_text(test_source(checks))
    (root/'Info.plist').write_bytes(plistlib.dumps({'CFBundleDisplayName':'芽の試作品','CFBundleURLTypes':[{'CFBundleURLSchemes':[scheme]}],'CFBundleIdentifier':'$(PRODUCT_BUNDLE_IDENTIFIER)','CFBundleExecutable':'$(EXECUTABLE_NAME)','CFBundleName':'$(PRODUCT_NAME)','CFBundlePackageType':'APPL','CFBundleShortVersionString':'1.0','CFBundleVersion':'1','UILaunchScreen':{},'UIApplicationSceneManifest':{'UIApplicationSupportsMultipleScenes':False},'UISupportedInterfaceOrientations':['UIInterfaceOrientationPortrait']}))
    objects={}
    def obj(isa,**kw):
        id=f'{len(objects)+1:024X}';objects[id]={'isa':isa,**kw};return id
    appfile=obj('PBXFileReference',path='NativeApp.swift',sourceTree='<group>',lastKnownFileType='sourcecode.swift')
    testfile=obj('PBXFileReference',path='AppChecks.swift',sourceTree='<group>',lastKnownFileType='sourcecode.swift')
    product=obj('PBXFileReference',path='Preview.app',sourceTree='BUILT_PRODUCTS_DIR',explicitFileType='wrapper.application')
    testproduct=obj('PBXFileReference',path='AppChecks.xctest',sourceTree='BUILT_PRODUCTS_DIR',explicitFileType='wrapper.cfbundle')
    products=obj('PBXGroup',children=[product,testproduct],name='Products',sourceTree='<group>')
    group=obj('PBXGroup',children=[appfile,testfile,products],sourceTree='<group>')
    def configs(settings):
        ids=[obj('XCBuildConfiguration',name=name,buildSettings=settings) for name in ['Debug','Release']]
        return obj('XCConfigurationList',buildConfigurations=ids,defaultConfigurationIsVisible='0',defaultConfigurationName='Debug')
    base={'SDKROOT':'iphoneos','SUPPORTED_PLATFORMS':'iphoneos iphonesimulator','SUPPORTS_MACCATALYST':'NO','SUPPORTS_MAC_DESIGNED_FOR_IPHONE_IPAD':'NO','ONLY_ACTIVE_ARCH':'YES','IPHONEOS_DEPLOYMENT_TARGET':'17.0','SWIFT_VERSION':'5.0','TARGETED_DEVICE_FAMILY':'1','CODE_SIGN_STYLE':'Automatic','SWIFT_OPTIMIZATION_LEVEL':'-Onone','CLANG_ENABLE_MODULES':'YES','ENABLE_USER_SCRIPT_SANDBOXING':'YES'}
    projectconfigs=configs(base)
    def target(name,source,product,settings,kind):
        buildfile=obj('PBXBuildFile',fileRef=source)
        phase=obj('PBXSourcesBuildPhase',buildActionMask='2147483647',files=[buildfile],runOnlyForDeploymentPostprocessing='0')
        frameworks=obj('PBXFrameworksBuildPhase',buildActionMask='2147483647',files=[],runOnlyForDeploymentPostprocessing='0')
        return obj('PBXNativeTarget',name=name,productName=name,productReference=product,productType=kind,buildConfigurationList=configs(settings),buildPhases=[phase,frameworks],dependencies=[],buildRules=[])
    app=target('Preview',appfile,product,{'PRODUCT_BUNDLE_IDENTIFIER':bundle,'PRODUCT_NAME':'Preview','INFOPLIST_FILE':'Info.plist'},'com.apple.product-type.application')
    tests=target('AppChecks',testfile,testproduct,{'PRODUCT_BUNDLE_IDENTIFIER':bundle+'.checks','PRODUCT_NAME':'AppChecks','GENERATE_INFOPLIST_FILE':'YES','TEST_TARGET_NAME':'Preview'},'com.apple.product-type.bundle.ui-testing')
    project=obj('PBXProject',attributes={'LastUpgradeCheck':'1600','TargetAttributes':{tests:{'TestTargetID':app}}},buildConfigurationList=projectconfigs,compatibilityVersion='Xcode 14.0',developmentRegion='ja',knownRegions=['ja','en','Base'],mainGroup=group,productRefGroup=products,projectDirPath='',projectRoot='',targets=[app,tests])
    proxy=obj('PBXContainerItemProxy',containerPortal=project,proxyType='1',remoteGlobalIDString=app,remoteInfo='Preview')
    dep=obj('PBXTargetDependency',target=app,targetProxy=proxy);objects[tests]['dependencies']=[dep]
    projectdir=root/'Preview.xcodeproj';projectdir.mkdir(exist_ok=True)
    (projectdir/'project.pbxproj').write_bytes(plistlib.dumps({'archiveVersion':'1','objectVersion':'56','classes':{},'objects':objects,'rootObject':project}))
    shared=projectdir/'xcshareddata/xcschemes';shared.mkdir(parents=True,exist_ok=True)
    ref=lambda id,name,product:f'<BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{id}" BuildableName="{product}" BlueprintName="{name}" ReferencedContainer="container:Preview.xcodeproj"/>'
    (shared/'Preview.xcscheme').write_text(f'''<?xml version="1.0"?><Scheme LastUpgradeVersion="1600" version="1.3"><BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES">{ref(app,'Preview','Preview.app')}</BuildActionEntry></BuildActionEntries></BuildAction><TestAction buildConfiguration="Debug" shouldUseLaunchSchemeArgsEnv="YES"><Testables><TestableReference skipped="NO">{ref(tests,'AppChecks','AppChecks.xctest')}</TestableReference></Testables></TestAction><LaunchAction buildConfiguration="Debug" useCustomWorkingDirectory="NO" launchStyle="0" debugServiceExtension="internal" allowLocationSimulation="NO"><BuildableProductRunnable runnableDebuggingMode="0">{ref(app,'Preview','Preview.app')}</BuildableProductRunnable></LaunchAction></Scheme>''')
