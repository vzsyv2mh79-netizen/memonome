"""Bounded prototype builder. No shell execution, deployment, paid API. Only explicit plan-limit failures retry."""
import json
import time
import uuid
import subprocess
import sys
import os
from pathlib import Path
import requests
from auth import atomic_json, RESOURCE

MAX_FILE = 300_000
MAX_QUEUE = 5_000_000
MAX_OUTPUT = 1_000_000
LIMIT_CODES = {'subscription_sharing_usage_limit_exceeded', 'subscription_sharing_usage_unavailable'}


class Paused(Exception):
    pass

class PlanLimit(Paused):
    def __init__(self, retry_after=0):
        super().__init__('ChatGPTの利用枠の回復待ちです。回復後に自動再開します。')
        self.retry_after = retry_after



def read_json(path):
    path = Path(path)
    if path.is_symlink() or path.stat().st_size > MAX_FILE:
        raise ValueError('受信データが大きすぎるか、安全に読み込めません。')
    return json.loads(path.read_text())


def queue_size(root):
    total = 0
    for p in root.iterdir():
        if p.is_symlink():
            raise ValueError('同期フォルダ内のリンクには対応していません。')
        if p.is_file():
            total += p.stat().st_size
    return total


def consume_stream(lines, cancelled):
    chunks, total, completed = [], 0, False
    for line in lines:
        if cancelled():
            raise Paused('停止しました。')
        if not line or not line.startswith('data: '):
            continue
        if line == 'data: [DONE]':
            break
        event = json.loads(line[6:])
        kind = event.get('type')
        if kind == 'response.output_text.delta':
            value = event.get('delta', '')
            total += len(value.encode())
            if total > MAX_OUTPUT:
                raise Paused('出力上限で停止しました。')
            chunks.append(value)
        elif kind in ('response.failed', 'error', 'response.incomplete'):
            error = event.get('response', {}).get('error') or event.get('error') or event
            code = error.get('code', 'response_incomplete') if isinstance(error, dict) else 'unknown_error'
            if code == 'subscription_sharing_usage_limit_exceeded':
                raise PlanLimit()
            raise Paused('利用枠を確認してください。' if code in LIMIT_CODES else 'AI処理が完了しませんでした。')
        elif kind == 'response.completed':
            completed = True
    if not completed:
        raise Paused('通信が途中で終了しました。自動で再送しません。')
    return ''.join(chunks)


def save_project(root, result):
    if result.startswith('```'):
        result = result.split('\n', 1)[1].rsplit('```', 1)[0]
    data = json.loads(result)
    files = data.get('files', [])
    if not isinstance(files, list) or len(files) > 30:
        raise ValueError('作成するファイル数が上限を超えました。')
    prepared = []
    for item in files:
        relative = Path(item['path'])
        if relative.is_absolute() or '..' in relative.parts or any(p.startswith('.') for p in relative.parts):
            raise ValueError('プロジェクト外への書き込みを拒否しました。')
        if relative.suffix.lower() not in {'.html', '.css', '.js', '.json', '.md', '.txt', '.svg'}:
            raise ValueError('対応しないファイル形式です。')
        target = (root / relative).resolve()
        if not target.is_relative_to(root.resolve()) or target == root.resolve():
            raise ValueError('書き込み先が不正です。')
        content = item['content']
        if not isinstance(content, str) or len(content.encode()) > MAX_FILE:
            raise ValueError('ファイル容量の上限です。')
        prepared.append((target, content))
    root.mkdir(parents=True, exist_ok=True)
    for target, content in prepared:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content)
    return str(data.get('summary', '試作品を作成しました。'))[:5000]


class Worker:
    def __init__(self, auth, sync, local):
        self.auth, self.sync, self.local = auth, Path(sync), Path(local)
        self.ledger_file = self.local / 'ledger.json'
        self.ledger = read_json(self.ledger_file) if self.ledger_file.exists() else {'jobs': {}, 'day': '', 'calls': 0, 'blocked': False}
        self.running = False
        self.model = ''

    def persist(self):
        atomic_json(self.ledger_file, self.ledger)

    def status(self, request, state, percent, message, **extra):
        atomic_json(self.sync / (request['id'] + '.status.json'), dict(
            id=request['id'], revision=request['revision'], state=state, percent=percent,
            message=message, updated=time.time(), **extra))

    def cancelled(self, request):
        if not self.running:
            return True
        current = read_json(self.sync / (request['id'] + '.request.json'))
        cancelled = current.get('action') != 'run' or current.get('revision') != request['revision']
        if not cancelled and time.time() - getattr(self, '_heartbeat', 0) > 20:
            path = self.sync / (request['id'] + '.status.json')
            if path.exists():
                value = read_json(path)
                if value.get('revision') == request['revision'] and value.get('state') == 'running':
                    value['updated'] = time.time(); atomic_json(path, value)
            self._heartbeat = time.time()
        return cancelled

    def tick(self):
        if not self.running or self.ledger['blocked']:
            return
        if time.time() < self.ledger.get('retry_at', 0):
            return
        if queue_size(self.sync) > MAX_QUEUE:
            self.ledger['blocked'] = True
            self.persist()
            return
        for path in sorted(self.sync.glob('*.request.json')):
            request = read_json(path)
            identifier = str(uuid.UUID(request['id'])).upper()
            if request['id'] != identifier or path.name != identifier + '.request.json':
                continue
            revision = str(uuid.UUID(request['revision'])).upper()
            if request.get('action') == 'approve':
                previous = self.sync / (identifier + '.status.json')
                if previous.exists():
                    result = read_json(previous)
                    if result.get('revision') == revision and result.get('state') == 'review_native':
                        self.status(request, 'approved', 95, 'iPhoneでの確認OKを受け付けました。App Storeへの提出・公開はまだ行っていません。', previewURL=result.get('previewURL'))
                continue
            if request.get('action') != 'run' or not isinstance(request.get('text'), str) or len(request['text']) > 30000:
                continue
            key = identifier + ':' + revision
            if time.time() < self.ledger.get('job_retry_at', {}).get(key, 0):
                continue
            if key in self.ledger['jobs'] and self.ledger['jobs'][key] not in ('waiting_quota', 'started', 'checkpointed', 'paused', 'waiting_device'):
                continue
            day = time.strftime('%Y-%m-%d')
            if self.ledger['day'] != day:
                self.ledger.update(day=day, calls=0)
            self.ledger['jobs'][key] = 'started'
            self.persist()  # Completed stages are durable; only an unfinished stage may repeat.
            try:
                checkpoint = self.local / 'checkpoints' / identifier / (revision + '.json')
                native = request.get('target') == 'ios'
                stages = [('index.html', '画面の構造'), ('style.css', '見た目'), ('app.js', '操作・動き'), ('checks.json', '操作テスト')]
                if native: stages = [('NativeApp.swift', 'iPhoneアプリ'), ('ios-checks.json', 'iPhone操作テスト')]
                saved = {}
                if checkpoint.exists():
                    if checkpoint.is_symlink() or checkpoint.stat().st_size > 2_000_000:
                        raise ValueError('作業の保存データを読み込めません。')
                    saved = json.loads(checkpoint.read_text())
                    if not isinstance(saved, dict) or any(k not in dict(stages) for k in saved):
                        raise ValueError('作業の保存データが不正です。')
                pending = [(name, label) for name, label in stages if name not in saved]
                if not pending:
                    self.finish_native(request, identifier, revision, key, saved) if native else self.finish_saved(request, identifier, revision, key, saved)
                    return
                name, label = pending[0]
                token = self.auth.token()
                if not self.model:
                    raise Paused('Macでモデルを選んでください。')
                self.status(request, 'running', 10 + len(saved) * 12, label + 'を作成中。完了した段階は保存済みです。')
                instructions = ('メモの要望を満たす実際に使えるローカルWebアプリを作る。データ保存にはlocalStorageを使う。今回は ' + name + ' だけを生成。'
                    'index.htmlはstyle.cssとdefer付きapp.jsを読み込む。HTMLに安定したidを付ける。'
                    '既に保存済みのファイルに合わせる。checks.jsonはメモの主要機能を確認する操作テスト。'
                    '形式は {\"tests\":[{\"name\":\"機能名\",\"steps\":[{\"action\":\"click\",\"selector\":\"#add\"},{\"action\":\"expect_text\",\"selector\":\"#result\",\"value\":\"期待値\"}]}]}。'
                    'actionはclick/fill/select/check/reload/expect_text/expect_value/expect_count/expect_visibleのみ。全テストに結果assert必須。保存機能はreload後も確認する。' 
                    '外部通信、CDN、課金、追跡、シェル実行、公開は禁止。'
                    'JSONのみ: {"summary":"実装内容と未検証点","files":[{"path":"' + name + '","content":"..."}]}。')
                if native: instructions = self.native_instructions(name)
                context = request['text'] + '\n保存済みのファイル（参照用）：\n' + json.dumps(saved, ensure_ascii=False)
                self.ledger['calls'] += 1
                self.persist()
                with requests.post(RESOURCE + '/responses', headers={'Authorization': 'Bearer ' + token},
                    json={'model': self.model, 'store': False, 'stream': True, 'instructions': instructions,
                          'input': [{'role': 'user', 'content': context}]}, stream=True, timeout=(15, 45)) as response:
                    if response.status_code != 200:
                        try:
                            body = response.json()
                            error = body.get('error', {}) if isinstance(body, dict) else {}
                            code = error.get('code') if isinstance(error, dict) else None
                        except Exception:
                            code = None
                        if code == 'subscription_sharing_usage_limit_exceeded':
                            try: retry_after = max(0, float(response.headers.get('Retry-After', 0)))
                            except (ValueError, TypeError): retry_after = 0
                            raise PlanLimit(retry_after)
                        raise Paused('利用枠または接続を確認してください。自動再試行は停止しました。')
                    response.encoding = 'utf-8'
                    result = consume_stream(response.iter_lines(decode_unicode=True), lambda: self.cancelled(request))
                if self.cancelled(request):
                    raise Paused('停止しました。')
                parsed = json.loads(result.removeprefix('```json').removeprefix('```').removesuffix('```').strip())
                files = parsed.get('files')
                if not isinstance(files, list) or len(files) != 1 or files[0].get('path') != name:
                    raise ValueError('今回の作業対象と異なるファイルが返されました。保存済みの作業は保持しています。')
                content = files[0].get('content')
                if not isinstance(content, str) or len(content.encode()) > MAX_FILE:
                    raise ValueError('作成ファイルの容量上限です。')
                saved[name] = content
                atomic_json(checkpoint, saved)  # Commit before status/files; replay requires no inference.
                self.ledger['jobs'][key] = 'checkpointed'
                self.ledger.update(retry_at=0, quota_attempts=0)
                if len(saved) == len(stages):
                    self.finish_native(request, identifier, revision, key, saved) if native else self.finish_saved(request, identifier, revision, key, saved)
                else:
                    self.status(request, 'running', 10 + len(saved) * 12, label + 'を保存しました。次の段階へ進みます。')
            except PlanLimit as e:
                # A pause/replacement wins over automatic quota recovery.
                if self.cancelled(request):
                    self.ledger['jobs'][key] = 'paused'
                    self.status(request, 'paused', 0, '停止しました。')
                else:
                    attempts = self.ledger.get('quota_attempts', 0) + 1
                    delay = max(min(900 * 2 ** min(attempts - 1, 2), 3600), e.retry_after)
                    self.ledger.update(retry_at=time.time() + delay, quota_attempts=attempts)
                    self.ledger['jobs'][key] = 'waiting_quota'
                    self.status(request, 'waiting_quota', 0, str(e) + ' 最初は15分後、その後は最大1時間ごとに再試行します。')
            except Exception as e:
                # Do not expose provider response bodies or tokens in shared files.
                print("Worker stopped:", type(e).__name__, flush=True)
                message = str(e) if isinstance(e, (Paused, ValueError)) else '接続または保存に失敗しました。Macで確認してください。'
                self.ledger['jobs'][key] = 'paused'
                if not (isinstance(e, Paused) and self.cancelled(request)):
                    self.ledger['blocked'] = True
                    self.running = False
                self.status(request, 'paused', 0, message)
            finally:
                self.persist()
            return

    def finish_saved(self, request, identifier, revision, key, saved):
        if self.cancelled(request):
            raise Paused('停止しました。')
        project = self.local / 'projects' / identifier / revision
        save_project(project, json.dumps({'files': [{'path': name, 'content': content} for name, content in saved.items()]}))
        report_file = project / 'verification.json'
        self.status(request, 'running', 60, 'Macでアプリを起動し、操作・保存・エラーを確認中です。')
        # Only this trusted runner executes; generated code runs inside Chromium.
        env = {k:v for k,v in os.environ.items() if k in ('HOME','PATH','TMPDIR','LANG','PLAYWRIGHT_BROWSERS_PATH')}
        proc = subprocess.Popen([sys.executable, str(Path(__file__).with_name('verify_app.py')), str(project), str(report_file)], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        started = time.time()
        try:
            while proc.poll() is None:
                if self.cancelled(request): raise Paused('停止しました。')
                if time.time()-started > 180: raise ValueError('動作確認が時間内に完了しませんでした。')
                time.sleep(.5)
        finally:
            if proc.poll() is None: proc.kill(); proc.wait()
        if proc.returncode != 0 or not report_file.exists():
            raise ValueError('動作確認用ブラウザを起動できませんでした。Macの設定を確認してください。')
        report = json.loads(report_file.read_text())
        if not report.get('passed'):
            attempts = self.ledger.setdefault('repairs', {}).get(key, 0)
            if attempts >= 3:
                raise Paused('3回修正しましたが動作確認で問題が残っています。確認結果はMacに保存済みです。')
            self.status(request, 'running', 65, '動作確認で見つかった問題を修正中です。')
            self.repair(request, key, saved, report)
            return
        if self.cancelled(request): raise Paused('停止しました。')
        names = '・'.join(str(t.get('name','操作')) for t in report['tests'])
        # Status before terminal ledger: a crash re-runs local tests, never AI generation.
        self.status(request, 'review', 70, 'Macで実装・起動・自動操作テストに合格しました。確認項目：' + names[:1500] + '。App Store向けのアプリ化・実機確認・審査・公開は未完了です。')
        self.ledger['jobs'][key] = 'completed'
        self.ledger.update(retry_at=0, quota_attempts=0)
        self.persist()

    def repair(self, request, key, saved, report):
        instructions = ('Webアプリの実行テストで不具合が出た。メモの要件を満たすよう実装を修正する。テストを弱めて成功させない。'
            '外部通信・CDN・課金は禁止。JSONのみ {"files":[{"path":"index.html|style.css|app.js|checks.json","content":"完全なファイル内容"}]}。変更ファイルのみ返す。'
            'checks.jsonの形式はtests配列、nameとsteps。操作はclick/fill/select/check/reload/expect_text/expect_value/expect_count/expect_visible。selectorとvalueを使う。')
        self.ledger['calls'] += 1
        self.persist()
        with requests.post(RESOURCE + '/responses', headers={'Authorization':'Bearer '+self.auth.token()}, json={'model':self.model,'store':False,'stream':True,'instructions':instructions,'input':[{'role':'user','content':json.dumps({'memo':request['text'],'files':saved,'verification':report},ensure_ascii=False)}]}, stream=True, timeout=(15,45)) as response:
            if response.status_code != 200:
                try: code = response.json().get('error',{}).get('code')
                except Exception: code = None
                if code == 'subscription_sharing_usage_limit_exceeded': raise PlanLimit()
                raise Paused('利用枠または接続を確認してください。')
            response.encoding = 'utf-8'
            result = consume_stream(response.iter_lines(decode_unicode=True), lambda:self.cancelled(request))
        data = json.loads(result.removeprefix('```json').removeprefix('```').removesuffix('```').strip())
        files = data.get('files',[])
        if not files or len(files)>4: raise ValueError('修正ファイルを読み取れませんでした。')
        for item in files:
            if item.get('path') not in saved or not isinstance(item.get('content'),str) or len(item['content'].encode())>MAX_FILE:
                raise ValueError('修正ファイルが不正です。')
        if self.cancelled(request): raise Paused('停止しました。')
        saved.update({item['path']:item['content'] for item in files})
        atomic_json(self.local/'checkpoints'/request['id']/(request['revision']+'.json'),saved)
        self.ledger.setdefault('repairs',{})[key] = self.ledger.get('repairs',{}).get(key,0)+1
        self.ledger['jobs'][key] = 'checkpointed'
        self.persist()

    def native_instructions(self, name):
        return ('メモの要望を実現する本物のSwiftUI iPhoneアプリを作る。今回は '+name+' だけ。'
            'NativeApp.swiftはimport SwiftUIとFoundationのみ、@main Appを含む単一ファイル。iOS17以降。外部通信・StoreKit・課金・追跡・外部依存・シェルは禁止。'
            '保存は@AppStorageまたはUserDefaults。AppのinitでCommandLine.arguments.contains("--ui-testing-reset")の時のみUserDefaults.standard.removePersistentDomain(forName:Bundle.main.bundleIdentifier!)で初期化。通常起動では消さない。'
            '操作部品と結果Textに固有のaccessibilityIdentifierを必ず付ける。テストが操作しやすいシンプルな画面。'
            'ios-checks.jsonは{"tests":[{"name":"日本語の確認項目","steps":[{"action":"tap","id":"add"},{"action":"expect_label","id":"count","value":"1"}]}]}。'
            'actionはtap,type,relaunch,expect_label,expect_value,expect_existsのみ。各テストは初期データから始まる。保存はrelaunchで確認。主要機能を結果まで検証。'
            'JSONのみ {"files":[{"path":"'+name+'","content":"完全な内容"}]}。')

    def finish_native(self, request, identifier, revision, key, saved):
        from native_runner import verify_and_install, NativeCancelled
        configfile = self.local / 'native-config.json'
        if not configfile.exists(): raise Paused('MacでiPhone開発用の設定が必要です。')
        project = self.local / 'projects' / identifier / revision / 'native'
        try:
            report = verify_and_install(project, saved, request, read_json(configfile), lambda state,percent,message:self.status(request,state,percent,message), lambda:self.cancelled(request))
        except NativeCancelled: raise Paused('停止しました。')
        atomic_json(project/'native-verification.json', report)
        if self.cancelled(request): raise Paused('停止しました。')
        if report['passed']:
            self.status(request,'review_native',90,'iPhoneアプリのビルド・自動操作テストが完了し、実機にインストールしました。「試作品を開く」で試してから確認OKを押してください。確認項目：'+'・'.join(report['tests'])[:1500],previewURL=report['previewURL'])
            self.ledger['jobs'][key]='completed'
            self.persist();return
        if report['phase']=='device':
            self.status(request,'waiting_device',85,'iPhoneへのインストール待ちです。Macにつないでロックを解除すると自動で再試行します。')
            self.ledger['jobs'][key]='waiting_device'
            self.ledger.setdefault('job_retry_at',{})[key]=time.time()+60
            self.persist();return
        if report['phase']=='environment': raise Paused('Macのシミュレータを起動できませんでした。AIでの再生成は行わず停止しました。')
        if report['phase']=='signing': raise Paused('実機向け署名で停止しました。MacのApple開発アカウント・証明書を確認してください。追加購入は行いません。')
        attempts=self.ledger.setdefault('native_repairs',{}).get(key,0)
        if attempts>=3:raise Paused('3回修正しましたがiPhoneの動作確認で問題が残っています。Macに検証結果を保存しました。')
        self.status(request,'running',60,'iPhoneアプリのビルド・操作テストの問題を修正中です。')
        self.repair_native(request,key,saved,report)

    def repair_native(self,request,key,saved,report):
        self.ledger['calls']+=1;self.persist()
        instructions=self.native_instructions('NativeApp.swift')+'今回はエラー修正。NativeApp.swiftとios-checks.jsonの必要なファイルのみ返す。テストを弱めて成功させない。'
        with requests.post(RESOURCE+'/responses',headers={'Authorization':'Bearer '+self.auth.token()},json={'model':self.model,'store':False,'stream':True,'instructions':instructions,'input':[{'role':'user','content':json.dumps({'memo':request['text'],'files':saved,'errors':report['diagnostic']},ensure_ascii=False)}]},stream=True,timeout=(15,45)) as response:
            if response.status_code!=200:
                try:code=response.json().get('error',{}).get('code')
                except Exception:code=None
                if code=='subscription_sharing_usage_limit_exceeded':raise PlanLimit()
                raise Paused('利用枠または接続を確認してください。')
            response.encoding='utf-8'
            result=consume_stream(response.iter_lines(decode_unicode=True),lambda:self.cancelled(request))
        data=json.loads(result.removeprefix('```json').removeprefix('```').removesuffix('```').strip())
        files=data.get('files',[])
        if not files or len(files)>2:raise ValueError('修正内容を読み取れませんでした。')
        for item in files:
            if item.get('path') not in saved or not isinstance(item.get('content'),str) or len(item['content'].encode())>MAX_FILE:raise ValueError('修正ファイルが不正です。')
        if self.cancelled(request):raise Paused('停止しました。')
        saved.update({item['path']:item['content'] for item in files})
        atomic_json(self.local/'checkpoints'/request['id']/(request['revision']+'.json'),saved)
        self.ledger['native_repairs'][key]=self.ledger['native_repairs'].get(key,0)+1
        self.ledger['jobs'][key]='checkpointed';self.persist()
