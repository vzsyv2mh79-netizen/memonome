from fixtures import FILES
import json,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'companion'))
from verify_app import verify
class Execution(unittest.TestCase):
 def test_browser_executes_and_checks_persistence(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d)
   for name,content in FILES.items():(root/name).write_text(content)
   self.assertTrue(verify(root)['passed'])
   (root/'app.js').write_text("document.querySelector('#add').onclick=()=>{}")
   self.assertFalse(verify(root)['passed'])
 def test_external_network_is_blocked(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d)
   for name,content in FILES.items():(root/name).write_text(content)
   (root/'index.html').write_text(FILES['index.html']+'<img src="https://example.com/forbidden">')
   self.assertFalse(verify(root)['passed'])
if __name__=='__main__':unittest.main()

class Repair(unittest.TestCase):
 def test_failed_execution_is_repaired_then_verified(self):
  from unittest.mock import patch
  from contextlib import nullcontext
  from worker import Worker
  from auth import atomic_json
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);sync=root/'sync';sync.mkdir();local=root/'local'
   rid='12345678-1234-4234-8234-123456789012';rev='12345678-1234-4234-8234-123456789013'
   request=dict(id=rid,revision=rev,action='run',text='保存するカウンター')
   atomic_json(sync/(rid+'.request.json'),request)
   broken=dict(FILES);broken['app.js']="document.querySelector('#add').onclick=()=>{}"
   atomic_json(local/'checkpoints'/rid/(rev+'.json'),broken)
   class Auth:
    def token(self):return 'synthetic-test-token'
   class Response:
    status_code=200
    def iter_lines(self,**kwargs):return iter(['data: '+json.dumps({'type':'response.output_text.delta','delta':json.dumps({'files':[{'path':'app.js','content':FILES['app.js']}]})}),'data: {"type":"response.completed"}'])
   w=Worker(Auth(),sync,local);w.running=True;w.model='test'
   with patch('worker.requests.post',return_value=nullcontext(Response())) as api:
    w.tick();self.assertEqual(api.call_count,1)
    self.assertEqual(w.ledger['jobs'][rid+':'+rev],'checkpointed')
    # Reboot between repair and re-test must not generate again.
    w=Worker(Auth(),sync,local);w.running=True;w.model='test';w.tick();w.tick()
    self.assertEqual(api.call_count,1)
   self.assertEqual(json.loads((sync/(rid+'.status.json')).read_text())['percent'],70)
