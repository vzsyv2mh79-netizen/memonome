from fixtures import FILES
import json,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from contextlib import nullcontext
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'companion'))
from worker import Worker
from auth import atomic_json
class Checkpoints(unittest.TestCase):
 def test_restart_skips_saved_stages_and_replays_local_finish(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);sync=root/'sync';sync.mkdir();local=root/'local';local.mkdir()
   rid='12345678-1234-4234-8234-123456789012';rev='12345678-1234-4234-8234-123456789013'
   req=dict(id=rid,revision=rev,action='run',text='test');atomic_json(sync/(rid+'.request.json'),req)
   class Auth:
    def token(self):return 'test'
   def worker():
    w=Worker(Auth(),sync,local);w.running=True;w.model='test';return w
   class Response:
    status_code=200
    def __init__(self,name):self.name=name
    def iter_lines(self,**kw):return iter(['data: '+json.dumps({'type':'response.output_text.delta','delta':json.dumps({'files':[{'path':self.name,'content':FILES[self.name]}]})}),'data: {"type":"response.completed"}'])
   with patch('worker.requests.post',return_value=nullcontext(Response('index.html'))):worker().tick()
   # Abrupt process loss while CSS is in flight leaves HTML committed.
   with patch('worker.requests.post',side_effect=SystemExit):
    with self.assertRaises(SystemExit):worker().tick()
   with patch('worker.requests.post',return_value=nullcontext(Response('style.css'))) as api:
    worker().tick();self.assertEqual(api.call_count,1)
    self.assertIn('style.css だけ',api.call_args.kwargs['json']['instructions'])
   with patch('worker.requests.post',return_value=nullcontext(Response('app.js'))):worker().tick()
   with patch('worker.requests.post',return_value=nullcontext(Response('checks.json'))):worker().tick()
   w=worker();w.ledger['jobs'][rid+':'+rev]='started';w.persist()
   with patch('worker.requests.post') as api:worker().tick();api.assert_not_called()
   self.assertEqual((local/'projects'/rid/rev/'index.html').read_text(),FILES['index.html'])
   # Stop always wins over a saved continuation.
   w=worker();w.ledger['jobs'][rid+':'+rev]='checkpointed';w.persist()
   req['action']='pause';atomic_json(sync/(rid+'.request.json'),req)
   with patch('worker.requests.post') as api:worker().tick();api.assert_not_called()
if __name__=='__main__':unittest.main()
