import json,sys,tempfile,unittest,uuid
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'companion'))
from native_project import test_source,create_project
from native_runner import verify_and_install
from worker import Worker
from auth import atomic_json
PLAN={'tests':[{'name':'表示','steps':[{'action':'expect_label','id':'count','value':'0'}]}]}
class NativeTests(unittest.TestCase):
 def test_rejects_commands_and_assertionless_tests(self):
  for step in [{'action':'shell','value':'bad'},{'action':'tap','id':'x'}]:
   with self.assertRaises(ValueError):test_source({'tests':[{'steps':[step]}]})
 def test_test_values_are_literals(self):
  code=test_source({'tests':[{'steps':[{'action':'expect_label','id':'x','value':'"\nprint("bad")'}]}]})
  self.assertIn('\\"\\nprint(\\"bad\\")',code)
 def test_restart_and_device_wait_do_not_rebuild(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);req={'id':str(uuid.uuid4()).upper()}
   saved={'NativeApp.swift':'import SwiftUI','ios-checks.json':json.dumps(PLAN)}
   config={'team':'ABCDEFGHIJ','simulator':str(uuid.uuid4()),'device':'00000001-0000000000000000'}
   with patch('native_runner.run',side_effect=[(0,''),(0,''),(1,'disconnected')]) as run:
    result=verify_and_install(root,saved,req,config,lambda *x:None,lambda:False)
    self.assertEqual(result['phase'],'device');self.assertEqual(run.call_count,3)
   with patch('native_runner.run',return_value=(0,'')) as run:
    result=verify_and_install(root,saved,req,config,lambda *x:None,lambda:False)
    self.assertTrue(result['passed']);self.assertEqual(run.call_count,1)
    verify_and_install(root,saved,req,config,lambda *x:None,lambda:False)
    self.assertEqual(run.call_count,1)
 def test_approval_requires_matching_tested_revision(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);sync=root/'sync';sync.mkdir();rid=str(uuid.uuid4()).upper();rev=str(uuid.uuid4()).upper()
   req=dict(id=rid,revision=rev,text='test',action='approve',target='ios')
   atomic_json(sync/(rid+'.request.json'),req)
   w=Worker(None,sync,root/'state');w.running=True
   w.status(req,'running',55,'testing');w.tick()
   self.assertEqual(json.loads((sync/(rid+'.status.json')).read_text())['percent'],55)
   w.status(req,'review_native',90,'tested',previewURL='memonome-preview-test://');w.tick()
   self.assertEqual(json.loads((sync/(rid+'.status.json')).read_text())['percent'],95)
if __name__=='__main__':unittest.main()
