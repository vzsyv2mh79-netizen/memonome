from fixtures import FILES
import json, tempfile, unittest, sys
from pathlib import Path
from contextlib import nullcontext
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'companion'))
from worker import Worker, PlanLimit, consume_stream
from auth import atomic_json

class RecoveryTests(unittest.TestCase):
 def test_quota_wait_recovery_and_manual_pause(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);sync=root/'sync';sync.mkdir();local=root/'local';local.mkdir()
   rid='12345678-1234-4234-8234-123456789012';rev='12345678-1234-4234-8234-123456789013'
   req=dict(id=rid,revision=rev,action='run',text='test');path=sync/(rid+'.request.json');atomic_json(path,req)
   class Auth:
    def token(self):return 'test'
   class Quota:
    status_code=429;headers={}
    def json(self):return {'error':{'code':'subscription_sharing_usage_limit_exceeded'}}
   class OK:
    status_code=200
    step=0
    def iter_lines(self,**kw):
     name=list(FILES)[self.step];self.step+=1
     return iter(['data: '+json.dumps({'type':'response.output_text.delta','delta':json.dumps({'files':[{'path':name,'content':FILES[name]}]})}),'data: {"type":"response.completed"}'])
   w=Worker(Auth(),sync,local);w.running=True;w.model='test'
   with patch('worker.time.time',return_value=1000),patch('worker.requests.post',return_value=nullcontext(Quota())) as api:
    w.tick();w.tick();self.assertEqual(api.call_count,1);self.assertEqual(w.ledger['retry_at'],1900)
   w=Worker(Auth(),sync,local);w.running=True;w.model='test'
   with patch('worker.requests.post',return_value=nullcontext(OK())) as api:
    w.tick();w.tick();w.tick();w.tick();self.assertEqual(api.call_count,4)
   self.assertEqual(w.ledger['jobs'][rid+':'+rev],'completed')
   w.ledger['jobs'][rid+':'+rev]='waiting_quota';req['action']='pause';atomic_json(path,req)
   with patch('worker.requests.post') as api:w.tick();api.assert_not_called()
 def test_stream_quota_is_retryable_but_transport_is_not(self):
  with self.assertRaises(PlanLimit):consume_stream(['data: {"type":"response.failed","response":{"error":{"code":"subscription_sharing_usage_limit_exceeded"}}}'],lambda:False)
if __name__=='__main__':unittest.main()
