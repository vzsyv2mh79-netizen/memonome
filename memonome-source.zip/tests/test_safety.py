import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'companion'))
from worker import consume_stream, Paused, save_project, Worker
from auth import atomic_json

class SafetyTests(unittest.TestCase):
    def test_partial_then_quota_never_succeeds(self):
        events = [{'type':'response.output_text.delta','delta':'partial'}, {'type':'response.failed','response':{'error':{'code':'subscription_sharing_usage_limit_exceeded'}}}]
        with self.assertRaises(Paused): consume_stream(['data: '+json.dumps(e) for e in events], lambda:False)
    def test_missing_completed_never_succeeds(self):
        with self.assertRaises(Paused):consume_stream(['data: {"type":"response.output_text.delta","delta":"x"}'],lambda:False)
    def test_pause_stops_stream(self):
        with self.assertRaises(Paused):consume_stream(['data: {"type":"response.completed"}'],lambda:True)
    def test_complete(self):
        self.assertEqual(consume_stream(['data: {"type":"response.output_text.delta","delta":"ok"}','data: {"type":"response.completed"}'],lambda:False),'ok')
    def test_project_traversal_and_symlink(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)/'project';root.mkdir()
            for path in ['../escape.html','/tmp/escape.html','.env','launch.command']:
                with self.assertRaises(ValueError):save_project(root,json.dumps({'files':[{'path':path,'content':'x'}]}))
            (root/'link').symlink_to(Path(directory),target_is_directory=True)
            with self.assertRaises(ValueError):save_project(root,json.dumps({'files':[{'path':'link/escape.html','content':'x'}]}))
    def test_credentials_are_private(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'credentials.json';atomic_json(path,{'test':True})
            self.assertEqual(path.stat().st_mode & 0o777,0o600)
    def test_completed_job_never_repeats_request(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);sync=root/'sync';sync.mkdir();local=root/'local';local.mkdir()
            rid='12345678-1234-4234-8234-123456789012';rev='12345678-1234-4234-8234-123456789013'
            atomic_json(sync/(rid+'.request.json'),dict(id=rid,revision=rev,action='run',text='test'))
            class Auth:
                def token(self):raise AssertionError('must not call')
            worker=Worker(Auth(),sync,local);worker.ledger['jobs'][rid+':'+rev]='completed';worker.persist()
            restarted=Worker(Auth(),sync,local);restarted.running=True;restarted.tick()
            self.assertEqual(restarted.ledger['calls'],0)
class EndToEndTests(unittest.TestCase):
    def test_request_build_status_and_no_duplicate(self):
        from contextlib import nullcontext
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);sync=root/'sync';sync.mkdir();local=root/'local';local.mkdir()
            rid='12345678-1234-4234-8234-123456789012';rev='12345678-1234-4234-8234-123456789013'
            atomic_json(sync/(rid+'.request.json'),dict(id=rid,revision=rev,action='run',text='test'))
            class Auth:
                def token(self):return 'synthetic-test-token'
            class Response:
                status_code=200
                step = 0
                def iter_lines(self,**kwargs):
                    name = ['index.html', 'style.css', 'app.js'][self.step]; self.step += 1
                    output=json.dumps({'summary':'試作品','files':[{'path':name,'content':'<!doctype html><h1>Test</h1>'}]})
                    return iter(['data: '+json.dumps({'type':'response.output_text.delta','delta':output}),'data: {"type":"response.completed"}'])
            worker=Worker(Auth(),sync,local);worker.model='test-model';worker.running=True
            import time
            worker.ledger.update(day=time.strftime('%Y-%m-%d'),calls=100)
            with patch('worker.requests.post',return_value=nullcontext(Response())) as api:
                worker.tick();worker.tick();worker.tick();worker.tick()
                self.assertEqual(api.call_count,3)
                self.assertEqual(api.call_args.kwargs['json']['store'],False)
            status=json.loads((sync/(rid+'.status.json')).read_text())
            self.assertEqual(status['state'],'review');self.assertEqual(status['percent'],40)
            self.assertTrue((local/'projects'/rid/rev/'index.html').exists())
    def test_quota_blocks_all_following_jobs(self):
        from contextlib import nullcontext
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);sync=root/'sync';sync.mkdir();local=root/'local';local.mkdir()
            for i in [1,2]:
                rid=f'12345678-1234-4234-8234-12345678901{i}'
                atomic_json(sync/(rid+'.request.json'),dict(id=rid,revision='12345678-1234-4234-8234-123456789019',action='run',text='test'))
            class Auth:
                def token(self):return 'synthetic-test-token'
            class Response:status_code=429
            worker=Worker(Auth(),sync,local);worker.model='test-model';worker.running=True
            with patch('worker.requests.post',return_value=nullcontext(Response())) as api:
                worker.tick();worker.tick();self.assertEqual(api.call_count,1)
            self.assertTrue(worker.ledger['blocked']);self.assertFalse(worker.running)
    def test_failed_auth_state_never_exchanges_code(self):
        from auth import Auth
        with tempfile.TemporaryDirectory() as directory:
            auth=Auth(directory);auth.begin('http://127.0.0.1:8771/auth/callback')
            with patch('auth.requests.post') as post:
                with self.assertRaises(ValueError):auth.finish({'state':'wrong','code':'fake'})
                post.assert_not_called()

if __name__=="__main__":unittest.main()
