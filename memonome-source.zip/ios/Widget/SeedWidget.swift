import SwiftUI
import WidgetKit
struct SeedEntry: TimelineEntry { let date: Date }
struct SeedProvider: TimelineProvider {
    func placeholder(in context: Context) -> SeedEntry { SeedEntry(date: .now) }
    func getSnapshot(in context: Context, completion: @escaping (SeedEntry) -> Void) { completion(SeedEntry(date: .now)) }
    func getTimeline(in context: Context, completion: @escaping (Timeline<SeedEntry>) -> Void) { completion(Timeline(entries: [SeedEntry(date: .now)], policy: .never)) }
}
struct Sprout: View {
    var body: some View {
        GeometryReader { g in
            Path { p in
                let w = g.size.width, h = g.size.height
                p.move(to: CGPoint(x:w*0.5,y:h*0.9))
                p.addQuadCurve(to: CGPoint(x:w*0.5,y:h*0.46),control: CGPoint(x:w*0.57,y:h*0.64))
                p.move(to: CGPoint(x:w*0.5,y:h*0.55))
                p.addCurve(to: CGPoint(x:w*0.1,y:h*0.2),control1: CGPoint(x:w*0.1,y:h*0.55),control2: CGPoint(x:w*0.1,y:h*0.2))
                p.addQuadCurve(to: CGPoint(x:w*0.5,y:h*0.55),control: CGPoint(x:w*0.52,y:h*0.18))
                p.move(to: CGPoint(x:w*0.5,y:h*0.45))
                p.addQuadCurve(to: CGPoint(x:w*0.9,y:h*0.1),control: CGPoint(x:w*0.5,y:h*0.1))
                p.addQuadCurve(to: CGPoint(x:w*0.5,y:h*0.45),control: CGPoint(x:w*0.9,y:h*0.45))
            }.stroke(style: StrokeStyle(lineWidth: 3, lineCap: .round, lineJoin: .round))
        }.aspectRatio(1, contentMode: .fit)
    }
}
struct SeedWidgetView: View {
    @Environment(\.widgetFamily) var family
    var body: some View {
        Group {
            if family == .accessoryCircular { Sprout().padding(7) }
            else if family == .accessoryInline { Text("🌱 ひらめきを残す") }
            else { HStack { Sprout().frame(width: 35, height: 35); VStack(alignment:.leading) { Text("ひらめきを残す").font(.headline); Text("タップしてメモ").font(.caption) } } }
        }
        .widgetURL(URL(string:"memonome://new"))
        .containerBackground(for: .widget) { Color(red:0.09,green:0.13,blue:0.1) }
        .accessibilityLabel("芽、新しいメモを開く")
    }
}
@main struct SeedWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind:"SeedQuickMemo",provider:SeedProvider()) { _ in SeedWidgetView() }
        .configurationDisplayName("🌱 すぐにメモ")
        .description("タップすると、新しいメモの入力画面が開きます。")
        .supportedFamilies([.accessoryCircular,.accessoryRectangular,.accessoryInline,.systemSmall])
    }
}
