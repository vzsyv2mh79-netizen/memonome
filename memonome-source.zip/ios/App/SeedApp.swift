import SwiftUI
import UniformTypeIdentifiers

struct Memo: Codable, Identifiable, Equatable {
    var id = UUID()
    var text: String
    var date = Date()
    var pinned = false
    var title: String { String(text.split(whereSeparator: \.isNewline).first ?? "無題のメモ") }
}
struct RemovedMemo: Codable, Identifiable {
    var memo: Memo
    var expires: Date
    var id: UUID { memo.id }
}
struct Library: Codable {
    var memos: [Memo] = []
    var trash: [RemovedMemo] = []
}
@MainActor final class Notes: ObservableObject {
    @Published private(set) var library = Library()
    @Published var error: String?
    private var readable = true
    private let file: URL
    init(file: URL = URL.documentsDirectory.appending(path: "library.json")) {
        self.file = file
        do { if FileManager.default.fileExists(atPath: file.path) { library = try JSONDecoder().decode(Library.self, from: Data(contentsOf: file)) } }
        catch { readable = false; self.error = "メモを読み込めませんでした。保存データを保護するため、アプリを開き直してください。" }
        expire()
    }
    @discardableResult func commit(_ next: Library) -> Bool {
        guard readable else { error = "保存データを読み込めていないため変更できません。"; return false }
        do {
            try JSONEncoder().encode(next).write(to: file, options: [.atomic, .completeFileProtection])
            library = next; return true
        } catch { self.error = "保存できませんでした。空き容量を確認してください。"; return false }
    }
    func save(id: UUID?, text: String) -> Bool {
        let value = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return false }
        var next = library
        if let id, let i = next.memos.firstIndex(where: { $0.id == id }) { next.memos[i].text = value; next.memos[i].date = .now }
        else { next.memos.insert(Memo(id: id ?? UUID(), text: value), at: 0) }
        return commit(next)
    }
    func pin(_ memo: Memo) { var next = library; if let i = next.memos.firstIndex(where: { $0.id == memo.id }) { next.memos[i].pinned.toggle(); commit(next) } }
    func remove(_ memo: Memo) {
        var next = library; next.memos.removeAll { $0.id == memo.id }
        next.trash.removeAll { $0.id == memo.id }
        next.trash.insert(RemovedMemo(memo: memo, expires: .now.addingTimeInterval(86400)), at: 0); commit(next)
    }
    func restore(_ removed: RemovedMemo) {
        guard removed.expires > Date() else { expire(); return }
        var next = library; next.trash.removeAll { $0.id == removed.id }
        if !next.memos.contains(where: { $0.id == removed.id }) { next.memos.insert(removed.memo, at: 0) }; commit(next)
    }
    func expire() { var next = library; next.trash.removeAll { $0.expires <= Date() }; if next.trash.count != library.trash.count { commit(next) } }
    func importNotes(_ data: Data) throws {
        guard data.count <= 10_000_000 else { throw CocoaError(.fileReadTooLarge) }
        let incoming = try JSONDecoder().decode([Memo].self, from: data)
        guard incoming.count <= 10000, incoming.allSatisfy({ !$0.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && $0.text.count <= 100000 }) else { throw CocoaError(.fileReadCorruptFile) }
        var next = library
        for memo in incoming where !next.memos.contains(where: { $0.id == memo.id }) {
            next.memos.append(memo); next.trash.removeAll { $0.id == memo.id }
        }
        if !commit(next) { throw CocoaError(.fileWriteUnknown) }
    }
}
struct Backup: FileDocument {
    static var readableContentTypes: [UTType] { [.json] }
    var data: Data
    init(_ notes: [Memo]) { data = (try? JSONEncoder().encode(notes)) ?? Data() }
    init(configuration: ReadConfiguration) throws { data = configuration.file.regularFileContents ?? Data() }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper { FileWrapper(regularFileWithContents: data) }
}
@main struct SeedApp: App {
    @StateObject private var notes = Notes()
    @StateObject private var connection = Connection()
    @StateObject private var tips = TipStore()
    var body: some Scene { WindowGroup { Home().environmentObject(notes).environmentObject(connection).environmentObject(tips) } }
}
struct Home: View {
    @EnvironmentObject private var connection: Connection
    @EnvironmentObject private var notes: Notes
    @Environment(\.scenePhase) private var scenePhase
    @AppStorage("theme") private var theme = "system"
    @State private var query = ""
    @State private var onlyPinned = false
    @State private var compose = false
    @State private var settings = false
    var visible: [Memo] {
        notes.library.memos.filter { (!onlyPinned || $0.pinned) && (query.isEmpty || $0.text.localizedStandardContains(query)) }
            .sorted { $0.pinned != $1.pinned ? $0.pinned : $0.date > $1.date }
    }
    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("小さなひらめきを、育てよう。").font(.title2.bold())
                        Text("まとまっていなくても、大丈夫。\n思いついたことからひとつずつ。").foregroundStyle(.secondary)
                        Button { compose = true } label: {
                            HStack(spacing: 8) {
                                Image(systemName: "square.and.pencil").accessibilityHidden(true)
                                Text("ひらめきを残す")
                            }
                            .font(.headline)
                            .padding(.vertical, 8)
                        }
                            .buttonStyle(.borderedProminent)
                    }.padding(.vertical, 8)
                    Toggle("お気に入りだけ", isOn: $onlyPinned)
                }
                Section("あなたのメモ · \(visible.count)") {
                    if visible.isEmpty { ContentUnavailableView(query.isEmpty ? "ここから、ひと芽。" : "見つかりませんでした", systemImage: "leaf", description: Text(query.isEmpty ? "＋から最初のメモを残そう。" : "別の言葉で探してみてください。")) }
                    ForEach(visible) { memo in
                        NavigationLink {
                            Detail(id: memo.id)
                        } label: {
                            HStack { if memo.pinned { Image(systemName: "star.fill").foregroundStyle(.orange) }; Text(memo.title).lineLimit(1); Spacer(); if let status = connection.statuses[memo.id] { Text("\(status.percent)%").font(.caption).foregroundStyle(.secondary); if status.state == "running" && status.isFresh && connection.requests[memo.id]?.revision == status.revision { ProgressView().controlSize(.small) } } }
                        }
                        .swipeActions(edge: .trailing, allowsFullSwipe: false) { Button("削除", role: .destructive) { notes.remove(memo) } }
                        .swipeActions(edge: .leading) { Button { notes.pin(memo) } label: { Label(memo.pinned ? "解除" : "お気に入り", systemImage: "star") }.tint(.orange) }
                    }
                }
                if !notes.library.trash.isEmpty {
                    Section("削除を取り消す · 24時間以内") {
                        ForEach(notes.library.trash) { removed in
                            Button { notes.restore(removed) } label: {
                                VStack(alignment: .leading, spacing: 4) { Text("削除を取り消す"); Text(removed.memo.title).font(.caption).foregroundStyle(.secondary).lineLimit(1) }
                            }
                        }
                    }
                }
                Section { Text("メモはこの端末に保存されます。AIなしでも、オフラインでも使えます。").font(.caption).foregroundStyle(.secondary) }
            }
            .navigationTitle("🌱 芽")
            .searchable(text: $query, prompt: "メモを探す")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button { settings = true } label: { Image(systemName: "gearshape") }.accessibilityLabel("設定") }
                ToolbarItem(placement: .topBarTrailing) { Button { compose = true } label: { Image(systemName: "plus") }.accessibilityLabel("新しいメモ") }
            }
            .sheet(isPresented: $compose) { Editor(memo: nil) }
            .sheet(isPresented: $settings) { Settings() }
            .onOpenURL { if $0.scheme == "memonome", $0.host == "new" { compose = true } }
            .onChange(of: scenePhase) { _, phase in if phase == .active { notes.expire() } }
            .task { while !Task.isCancelled { notes.expire(); connection.refresh(); do { try await Task.sleep(for: .seconds(15)) } catch { break } } }
            .alert("Mac連携", isPresented: Binding(get: { connection.message != nil }, set: { if !$0 { connection.message = nil } })) { Button("OK") { connection.message = nil } } message: { Text(connection.message ?? "") }
            .alert("保存について", isPresented: Binding(get: { notes.error != nil }, set: { if !$0 { notes.error = nil } })) { Button("閉じる") { notes.error = nil } } message: { Text(notes.error ?? "") }
        }
        .tint(Color(red: 0.27, green: 0.55, blue: 0.34))
        .preferredColorScheme(theme == "dark" ? .dark : theme == "light" ? .light : nil)
    }
}
struct Editor: View {
    @EnvironmentObject private var connection: Connection
    @AppStorage("autoDevelopNewNotes") private var autoDefault = false
    @State private var sendToAI = false
    @State private var newID = UUID()
    @EnvironmentObject private var notes: Notes
    @Environment(\.dismiss) private var dismiss
    @AppStorage("draft") private var draft = ""
    let memo: Memo?
    @State private var text = ""
    @FocusState private var focused: Bool
    var body: some View {
        NavigationStack {
            VStack(alignment: .leading) {
                Text("最初の行がタイトルになります。").font(.caption).foregroundStyle(.secondary).padding(.horizontal)
                Toggle("AIにおまかせ", isOn: $sendToAI).padding(.horizontal)
                if sendToAI { Text("保存後、自分のMacとOpenAIへ送り、本人の利用枠で開発と動作確認を進めます。").font(.caption).foregroundStyle(.secondary).padding(.horizontal) }
                TextEditor(text: $text).padding(12).focused($focused).accessibilityLabel("メモ本文")
            }
            .navigationTitle(memo == nil ? "新しいひらめき" : "メモを編集")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("あとで") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("保存") { if notes.save(id: memo?.id ?? newID, text: text) { if sendToAI, let saved = notes.library.memos.first(where: { $0.id == (memo?.id ?? newID) }) { connection.submit(saved, run: true) }; if memo == nil { draft = "" }; dismiss() } }.disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) }
            }
            .onAppear { text = memo?.text ?? draft; sendToAI = memo == nil && autoDefault; focused = true }
            .onChange(of: text) { _, value in if memo == nil { draft = value } }
            .interactiveDismissDisabled(memo != nil && text != memo?.text)
        }
    }
}
struct Detail: View {
    @EnvironmentObject private var notes: Notes
    let id: UUID
    @State private var edit = false
    @State private var ai = false
    var memo: Memo? { notes.library.memos.first { $0.id == id } }
    var body: some View {
        Group {
            if let memo {
                List {
                    Section { Text(memo.text).textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading); Text(memo.date, format: .dateTime.year().month().day().hour().minute()).font(.caption).foregroundStyle(.secondary) }
                    DevelopmentPanel(memo: memo)
                    Section {
                        Button { ai = true } label: { Label("自分のAIに相談する", systemImage: "sparkles") }
                        ShareLink(item: memo.text) { Label("メモを共有", systemImage: "square.and.arrow.up") }
                        Button { notes.pin(memo) } label: { Label(memo.pinned ? "お気に入りを解除" : "お気に入りにする", systemImage: memo.pinned ? "star.fill" : "star") }
                    }
                }.navigationTitle(memo.title).navigationBarTitleDisplayMode(.inline)
                    .toolbar { Button("編集") { edit = true } }
                    .sheet(isPresented: $edit) { Editor(memo: memo) }
                    .sheet(isPresented: $ai) { AIShare(memo: memo) }
            } else { ContentUnavailableView("メモが見つかりません", systemImage: "leaf") }
        }
    }
}
struct AIShare: View {
    let memo: Memo
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL
    @AppStorage("provider") private var provider = "ChatGPT"
    @State private var task = "わかりやすく整理"
    @State private var copied = false
    let providers = ["ChatGPT", "Claude", "Gemini"]
    var prompt: String { "次のメモをもとに、\(task)してください。提案と事実を区別し、確認が必要な点も教えてください。\n\n" + memo.text }
    var url: URL { URL(string: ["ChatGPT":"https://chatgpt.com/", "Claude":"https://claude.ai/", "Gemini":"https://gemini.google.com/"][provider] ?? "https://chatgpt.com/")! }
    var body: some View {
        NavigationStack {
            Form {
                Section("相談する相手") { Picker("AI", selection: $provider) { ForEach(providers, id: \.self) { Text($0) } }; Picker("頼みたいこと", selection: $task) { ForEach(["わかりやすく整理", "アイデアを広げる提案", "次の一歩を具体化"], id: \.self) { Text($0) } } }
                Section("渡す内容を確認") { Text(prompt).font(.body).textSelection(.enabled) }
                Section {
                    Button("内容をコピーして\(provider)を開く") {
                        UIPasteboard.general.setItems([[UTType.utf8PlainText.identifier: prompt]], options: [.localOnly: true, .expirationDate: Date().addingTimeInterval(300)])
                        copied = true; openURL(url)
                    }
                    ShareLink(item: prompt) { Label("共有メニューから渡す", systemImage: "square.and.arrow.up") }
                    if copied { Text("コピーしました。AIの入力欄に貼り付けて送信してください。").font(.caption) }
                } footer: { Text("芽はAIのアカウントやAPIキーを預かりません。コピーだけではAIに送信されません。選んだAI側で貼り付け・送信すると、そのサービスの規約・データの扱い・利用制限が適用されます。共有する内容をご確認ください。") }
            }
            .navigationTitle("自分のAIへ").navigationBarTitleDisplayMode(.inline)
            .toolbar { Button("閉じる") { dismiss() } }
        }
    }
}
struct Settings: View {
    @EnvironmentObject private var notes: Notes
    @Environment(\.dismiss) private var dismiss
    @AppStorage("theme") private var theme = "system"
    @State private var export = false
    @State private var importing = false
    @State private var message: String?
    var body: some View {
        NavigationStack {
            Form {
                Section("AI・応援") { NavigationLink("ChatGPT・Mac連携") { ConnectionSettings() }; NavigationLink("チップで応援する") { Tips() } }
                Section("見た目") { Picker("画面の色", selection: $theme) { Text("端末に合わせる").tag("system"); Text("ライト").tag("light"); Text("ダーク").tag("dark") } }
                Section("メモを守る") {
                    Button("メモを書き出す") { export = true }
                    Button("バックアップを読み込む") { importing = true }
                    Text("端末の故障やアプリ削除に備えて、ファイルに保存できます。読み込みは今のメモを残し、未登録のメモだけ追加します。削除済みメモは書き出しません。").font(.caption).foregroundStyle(.secondary)
                }
                Section("使い方") {
                    Text("ロック画面を長押し → カスタマイズ → ウィジェット → 芽メモ。タップするとすぐに入力できます。")
                    Text("AIは任意です。メモを開いて「自分のAIに相談する」から内容をコピーし、普段のAIで送信してください。Mac連携を設定すると、選んだメモからWebアプリを開発し、Macで動作確認できます。")
                }
                Section("プライバシーとサポート") {
                    NavigationLink("プライバシーポリシー") { Privacy() }
                    Link("メールで問い合わせ", destination: URL(string: "mailto:soccer16black@gmail.com")!)
                    Text("芽メモ 1.1 開発版\nメモはログイン不要・広告なし・任意のチップあり").font(.caption).foregroundStyle(.secondary)
                }
            }.navigationTitle("設定").toolbar { Button("閉じる") { dismiss() } }
            .fileExporter(isPresented: $export, document: Backup(notes.library.memos), contentType: .json, defaultFilename: "芽メモ-バックアップ") { result in if case .failure = result { message = "書き出しを完了できませんでした。" } }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.json]) { result in
                do {
                    let url = try result.get(); let allowed = url.startAccessingSecurityScopedResource(); defer { if allowed { url.stopAccessingSecurityScopedResource() } }
                    try notes.importNotes(Data(contentsOf: url)); message = "メモを読み込みました。"
                } catch { message = "読み込めませんでした。芽メモのバックアップファイルを選んでください。" }
            }
            .alert("バックアップ", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) { Button("OK") { message = nil } } message: { Text(message ?? "") }
        }
    }
}
struct Privacy: View {
    var body: some View {
        ScrollView { Text("""
芽メモ プライバシーポリシー
更新日：2026年10月27日

メモ、下書き、お気に入り、削除取り消し情報、設定は端末内に保存します。開発者のサーバーへの収集は行いません。Mac連携を設定して「AIにおまかせ」を選んだメモは、利用者が選んだ同期フォルダを通じて本人のMacへ渡り、OpenAIへ送信されます。同期サービスとOpenAIの規約・データの扱いが適用されます。Macの認証情報はMac内に保存されます。広告、追跡、分析SDKは使用しません。端末のバックアップ設定に応じてOSのバックアップに含まれる場合があります。

AIへの共有は利用者が選んだ内容に限ります。コピーしてAIを開く操作では、内容を端末のクリップボードへ5分間保存し、AIの公式ページを開きます。本文をURLには含めません。貼り付け・送信した内容は選択先のサービスに渡り、そのサービスの規約・プライバシーポリシーが適用されます。共有メニューの送信先や書き出しファイルの保存先も利用者が選びます。

削除したメモは24時間以内に復元できます。期限を過ぎると、アプリ起動時・利用中に端末内の取り消し情報を消去します。アプリを削除するとアプリ内のデータは削除されます。書き出したファイルや外部AIへ送信した内容、OSのバックアップはそれぞれの保存先で管理してください。

任意のチップはAppleのアプリ内購入で処理します。定期購入ではありません。開発者はカード情報を取得しません。購入確認にはAppleが提供する取引情報を端末上で使用します。

メールによるお問い合わせでは、返信のためにメールアドレスと問い合わせ内容を利用します。メモ本文や個人情報を不要に添付しないでください。対応終了後、必要な期間を超えて保持しません。

お問い合わせ：soccer16black@gmail.com
本アプリはOpenAI、Anthropic、Googleの公式アプリではありません。
""").padding(24).textSelection(.enabled) }.navigationTitle("プライバシー").navigationBarTitleDisplayMode(.inline)
    }
}
