import SwiftUI
import StoreKit

@MainActor final class TipStore: ObservableObject {
    static let ids = ["jp.shizuie.memonome.tip.small", "jp.shizuie.memonome.tip.medium", "jp.shizuie.memonome.tip.large"]
    @Published var products: [Product] = []
    @Published var message: String?
    @Published var busy = false
    private var listener: Task<Void, Never>?
    init() {
        listener = Task { [weak self] in
            for await result in Transaction.updates {
                guard case .verified(let transaction) = result, Self.ids.contains(transaction.productID) else { continue }
                await transaction.finish()
                self?.message = "応援ありがとうございます🌱"
            }
        }
    }
    deinit { listener?.cancel() }
    func load() async {
        do {
            products = try await Product.products(for: Self.ids).filter { $0.type == .consumable }.sorted { $0.price < $1.price }
            if products.isEmpty { message = "チップは現在準備中です。メモはそのまま無料で使えます。" }
        } catch { message = "価格を読み込めませんでした。あとでお試しください。" }
    }
    func purchase(_ product: Product) async {
        guard !busy else { return }
        busy = true; defer { busy = false }
        do {
            switch try await product.purchase() {
            case .success(let result):
                guard case .verified(let transaction) = result, Self.ids.contains(transaction.productID) else { message = "購入の確認ができませんでした。"; return }
                await transaction.finish()
                message = "応援ありがとうございます🌱"
            case .pending: message = "購入の承認を待っています。"
            case .userCancelled: break
            @unknown default: message = "購入状況を確認してください。"
            }
        } catch { message = "購入を完了できませんでした。" }
    }
}
struct Tips: View {
    @EnvironmentObject private var tips: TipStore
    var body: some View {
        List {
            Section {
                Text("芽メモを応援する 🌱").font(.title2.bold())
                Text("気に入ったら、開発をチップで応援できます。完全に任意で、購入しなくても使える機能は変わりません。")
            }
            Section {
                ForEach(tips.products, id: \.id) { product in
                    Button { Task { await tips.purchase(product) } } label: {
                        HStack { Text(product.displayName); Spacer(); Text(product.displayPrice).bold() }
                    }.disabled(tips.busy)
                }
                if tips.products.isEmpty { Button("価格を読み込む") { Task { await tips.load() } } }
            } header: { Text("1回だけのチップ") } footer: { Text("Appleの購入確認画面で金額を確認できます。定期購入ではなく、自動更新・自動課金はありません。AI利用枠や保存容量は増えません。") }
            if let message = tips.message { Section { Text(message) } }
        }.navigationTitle("チップで応援").task { await tips.load() }
    }
}
