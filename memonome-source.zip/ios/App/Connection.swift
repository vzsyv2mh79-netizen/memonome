import SwiftUI
import UniformTypeIdentifiers

struct DevelopmentStatus: Codable {
    let id: String
    let revision: String
    let state: String
    let percent: Int
    let message: String
    let updated: Double
    var previewURL: String? = nil
    var isFresh: Bool { Date().timeIntervalSince1970 - updated < 120 }
}
struct DevelopmentRequest: Codable {
    let id: String
    let revision: String
    let text: String
    let action: String
    var target: String? = nil
}
@MainActor final class Connection: ObservableObject {
    @Published var folderName: String = "未接続"
    @Published var message: String?
    @Published var statuses: [UUID: DevelopmentStatus] = [:]
    @Published var requests: [UUID: DevelopmentRequest] = [:]
    @Published private(set) var outbox: [String: DevelopmentRequest] = [:]
    private var outboxReadable = true
    private var outboxURL: URL { FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("development-outbox.json") }
    private func persistOutbox() throws {
        try FileManager.default.createDirectory(at: outboxURL.deletingLastPathComponent(), withIntermediateDirectories: true)
        try JSONEncoder().encode(outbox).write(to: outboxURL, options: [.atomic, .completeFileProtection])
    }
    func flush() {
        guard outboxReadable else { return }
        for (id, request) in outbox {
            do {
                try write(request)
                outbox.removeValue(forKey: id)
                do { try persistOutbox() } catch { outbox[id] = request }
            } catch { message = "送信待ちです。同期フォルダに接続できたら再送します。" }
        }
    }
    private var folder: URL?
    private let maxBytes = 5_000_000
    init() {
        if FileManager.default.fileExists(atPath: outboxURL.path) {
            do { outbox = try JSONDecoder().decode([String: DevelopmentRequest].self, from: Data(contentsOf: outboxURL)) }
            catch { outboxReadable = false; message = "送信待ちデータを読み込めません。アプリを開き直してください。" }
        }
        guard let data = UserDefaults.standard.data(forKey: "syncFolder") else { return }
        do {
            var stale = false
            let url = try URL(resolvingBookmarkData: data, options: [], relativeTo: nil, bookmarkDataIsStale: &stale)
            try connect(url)
        } catch { message = "同期フォルダを選び直してください。メモは端末に残っています。" }
    }
    func connect(_ url: URL) throws {
        guard url.startAccessingSecurityScopedResource() else { throw CocoaError(.fileReadNoPermission) }
        defer { url.stopAccessingSecurityScopedResource() }
        let data = try url.bookmarkData(options: .minimalBookmark, includingResourceValuesForKeys: nil, relativeTo: nil)
        UserDefaults.standard.set(data, forKey: "syncFolder")
        folder = url; folderName = url.lastPathComponent; refresh()
    }
    func disconnect() {
        guard outbox.isEmpty else { message = "送信待ちのメモがあります。同期してから解除してください。"; return }
        // Pausing all submitted requests must succeed before forgetting the folder.
        for request in requests.values where request.action == "run" {
            guard let id = UUID(uuidString: request.id) else { continue }
            do { try write(DevelopmentRequest(id: id.uuidString, revision: UUID().uuidString, text: "", action: "pause")) }
            catch { message = "停止を送れませんでした。Mac側でも停止してから解除してください。"; return }
        }
        folder = nil; folderName = "未接続"; requests = [:]; statuses = [:]
        UserDefaults.standard.removeObject(forKey: "syncFolder")
    }
    private func access<T>(_ operation: (URL) throws -> T) throws -> T {
        guard let folder, folder.startAccessingSecurityScopedResource() else { throw CocoaError(.fileReadNoPermission) }
        defer { folder.stopAccessingSecurityScopedResource() }
        return try operation(folder)
    }
    private func write(_ request: DevelopmentRequest) throws {
        try access { directory in
            let files = try FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: [.fileSizeKey, .isSymbolicLinkKey])
            var size = 0
            for file in files {
                let values = try file.resourceValues(forKeys: [.fileSizeKey, .isSymbolicLinkKey])
                if values.isSymbolicLink == true { throw CocoaError(.fileReadNoPermission) }
                size += values.fileSize ?? 0
            }
            let data = try JSONEncoder().encode(request)
            // Stop commands remain available when the mailbox is full.
            guard request.action == "pause" || size + data.count <= maxBytes else { throw CocoaError(.fileWriteOutOfSpace) }
            let target = directory.appendingPathComponent(request.id + ".request.json")
            var coordinationError: NSError?
            var writeError: Error?
            NSFileCoordinator().coordinate(writingItemAt: target, options: .forReplacing, error: &coordinationError) { url in
                do { try data.write(to: url, options: .atomic) } catch { writeError = error }
            }
            if let error = coordinationError ?? writeError as NSError? { throw error }
            requests[UUID(uuidString: request.id)!] = request
        }
    }
    func submit(_ memo: Memo, run: Bool) {
        guard memo.text.count <= 30000 else { message = "自動処理は3万文字以内のメモに対応しています。"; return }
        guard outboxReadable else { message = "送信待ちデータを保護するため送信を停止しています。"; return }
        let existing = outbox[memo.id.uuidString] ?? requests[memo.id]
        let target = run ? (UserDefaults.standard.string(forKey: "developmentTarget") ?? "ios") : (existing?.target ?? "ios")
        let revision = existing?.text == memo.text && existing?.target == target ? existing!.revision : UUID().uuidString
        let request = DevelopmentRequest(id: memo.id.uuidString, revision: revision, text: memo.text, action: run ? "run" : "pause", target: target)
        let previous = outbox[request.id]
        outbox[request.id] = request
        do { try persistOutbox() }
        catch { outbox[request.id] = previous; message = "送信予約を保存できませんでした。メモは端末に残っています。"; return }
        requests[memo.id] = request
        message = run ? "送信を予約しました。Macへの到着後に自動で開始します。" : "停止を予約しました。Macへの到着後に停止します。"
        flush()
    }

    func approve(_ memo: Memo) {
        guard let old = requests[memo.id], let status = statuses[memo.id], status.revision == old.revision, status.state == "review_native" else { return }
        let request = DevelopmentRequest(id: old.id, revision: old.revision, text: old.text, action: "approve", target: old.target)
        guard outboxReadable else { return }
        let previous = outbox[request.id]
        outbox[request.id] = request
        do { try persistOutbox() } catch { outbox[request.id] = previous; message = "確認結果を保存できませんでした。"; return }
        requests[memo.id] = request; flush()
        message = "確認OKを送信しました。App Storeへの提出・公開はまだ行いません。"
    }

    func refresh() {
        flush()
        do {
            try access { directory in
                let files = try FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: [.fileSizeKey, .isSymbolicLinkKey])
                var next: [UUID: DevelopmentStatus] = [:]
                var pending: [UUID: DevelopmentRequest] = [:]
                for file in files where file.lastPathComponent.hasSuffix(".json") {
                    let values = try file.resourceValues(forKeys: [.fileSizeKey, .isSymbolicLinkKey])
                    guard values.isSymbolicLink != true, (values.fileSize ?? 0) <= 300000 else { continue }
                    var data: Data?
                    var err: NSError?
                    NSFileCoordinator().coordinate(readingItemAt: file, options: [], error: &err) { data = try? Data(contentsOf: $0) }
                    guard let data else { continue }
                    if file.lastPathComponent.hasSuffix(".status.json"), let status = try? JSONDecoder().decode(DevelopmentStatus.self, from: data), let id = UUID(uuidString: status.id) { next[id] = status }
                    if file.lastPathComponent.hasSuffix(".request.json"), let request = try? JSONDecoder().decode(DevelopmentRequest.self, from: data), let id = UUID(uuidString: request.id) { pending[id] = request }
                }
                for request in outbox.values { if let id = UUID(uuidString: request.id) { pending[id] = request } }
                statuses = next; requests = pending
            }
        } catch { /* Offline notes remain usable; last known progress is marked stale. */ }
    }
}
struct ConnectionSettings: View {
    @EnvironmentObject private var connection: Connection
    @State private var choose = false
    @AppStorage("autoDevelopNewNotes") private var autoDefault = false
    @AppStorage("developmentTarget") private var developmentTarget = "ios"
    var body: some View {
        Form {
            Section("自分のMacとつなぐ") {
                Text("ChatGPTへのログインはMacで行います。iPhoneとMacで、同じ自分専用のiCloud Driveフォルダを選んでください。")
                Text("同期フォルダ：\(connection.folderName)")
                Button("同期フォルダを選ぶ") { choose = true }
                Button("接続を解除", role: .destructive) { connection.disconnect() }
            }
            Section("作るアプリ") {
                Picker("種類", selection: $developmentTarget) { Text("iPhoneアプリ").tag("ios"); Text("Webアプリ").tag("web") }
                Text("iPhoneアプリはMacでビルド・操作テスト後、接続したiPhoneにインストールします。Macへの接続とロック解除が必要です。")
            }
            Section("保存したら自動で開始") {
                Toggle("新しいメモをAIにおまかせ", isOn: $autoDefault)
                Text("オンにすると新規メモの保存時に自分のMacとOpenAIへ送ります。メモごとにオフにできます。送信待ち：\(connection.outbox.count)件").font(.caption)
            }
            Section("送信する内容") { Text("AIにおまかせを押したメモだけを同期フォルダへ保存します。Macが読み取り、OpenAIへ送信します。認証情報はMacに保存し、このフォルダへは送りません。ほかの人と共有しているフォルダは選ばないでください。") }
            Section("追加料金を使わない") {
                Text("有料APIへの切り替え・容量購入・クレジット購入は行いません。MacでChatGPTの追加クレジット使用をオフにしたことを確認してから開始します。回数制限は設けず、ChatGPTの利用枠に達したら停止します。同期データは5MBまでです。")
                Text("容量不足や同期の遅延は端末から検出できないことがあります。Macがオフラインの場合も待機します。メモ自体は端末内で使えます。")
            }
            Section("進捗の目安") { Text("iPhoneアプリは自動テスト後に実機へインストールし、90%であなたの確認を待ちます。実機で試して確認OKを押すと95%。審査と公開は別途必要で、公開完了が100%です。Webアプリは自動テスト完了が70%です。") }
        }.navigationTitle("ChatGPT・Mac連携")
            .fileImporter(isPresented: $choose, allowedContentTypes: [.folder]) { result in
                do { try connection.connect(result.get()) } catch { connection.message = "フォルダに接続できませんでした。" }
            }
    }
}
struct DevelopmentPanel: View {
    let memo: Memo
    @EnvironmentObject private var connection: Connection
    @State private var confirm = false
    @State private var approveConfirm = false
    @Environment(\.openURL) private var openURL
    var body: some View {
        Section("AIにおまかせ · 開発版") {
            if let status = connection.statuses[memo.id] {
                Text("\(min(100, max(0, status.percent)))% · \(status.state == "running" && status.isFresh && connection.requests[memo.id]?.revision == status.revision ? "開発中" : status.state == "waiting_quota" ? "利用枠の回復待ち" : status.state == "waiting_device" ? "iPhone接続待ち" : status.state == "review_native" ? "iPhoneで確認待ち" : status.state == "approved" ? "確認OK・公開準備待ち" : status.state == "review" ? "動作確認済み・確認待ち" : "停止中・接続確認")").font(.headline)
                Text(status.message).font(.subheadline).textSelection(.enabled)
                if status.revision == connection.requests[memo.id]?.revision, let address = status.previewURL, address.hasPrefix("memonome-preview-"), let url = URL(string: address), ["review_native", "approved"].contains(status.state) {
                    Button("試作品を開く") { openURL(url) }
                    if status.state == "review_native" { Button("iPhoneで試した・確認OK") { approveConfirm = true } }
                    Text("修正が必要ならメモを編集し、修正内容を追記して再開してください。").font(.caption)
                }
            }
            if connection.requests[memo.id]?.revision != connection.statuses[memo.id]?.revision {
                Text("Macへの到着・反映待ち").font(.caption).foregroundStyle(.secondary)
            }
            Button("AIにおまかせ・再開") { confirm = true }
            Button("開発の停止を依頼") { connection.submit(memo, run: false) }
            Text("本人のChatGPT利用枠を使用。Macが起動し、接続済みである必要があります。").font(.caption).foregroundStyle(.secondary)
        }.confirmationDialog("実際にiPhoneで試して、公開準備へ進んでよいですか？", isPresented: $approveConfirm, titleVisibility: .visible) {
            Button("確認OKを送る") { connection.approve(memo) }
            Button("キャンセル", role: .cancel) {}
        } message: { Text("この操作ではApp Storeへの提出・公開は行いません。") }
        .confirmationDialog("このメモをMacとOpenAIへ送って、開発と動作確認を進めますか？", isPresented: $confirm, titleVisibility: .visible) {
            Button("このメモで開始") { connection.submit(memo, run: true) }
            Button("キャンセル", role: .cancel) {}
        }
    }
}
