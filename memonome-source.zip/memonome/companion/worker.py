"""Bounded prototype builder. No shell execution, deployment, paid API or retries."""
import json
import time
import uuid
from pathlib import Path
import requests
from auth import atomic_json, RESOURCE

MAX_FILE = 300_000
MAX_QUEUE = 5_000_000
MAX_CALLS_PER_DAY = 3
MAX_OUTPUT = 1_000_000
LIMIT_CODES = {'subscription_sharing_usage_limit_exceeded', 'subscription_sharing_usage_unavailable'}


class Paused(Exception):
    pass


def read_json(path):
    path = Path(path)
    if path.is_symlink() or path.stat().st_size > MAX_FILE:
        raise ValueError('受信データが大きすぎるか、安全に読み込めません。')
    return json.loads(path.read_text())


def queue_size(root):
    total = 0
    for p in root.iterdir():
        if p.is_symlink():
            raise ValueError('同期フォルダ内のリンクには対応していません。')
        if p.is_file():
            total += p.stat().st_size
    return total


def consume_stream(lines, cancelled):
    chunks, total, completed = [], 0, False
    for line in lines:
        if cancelled():
            raise Paused('停止しました。')
        if not line or not line.startswith('data: '):
            continue
        if line == 'data: [DONE]':
            break
        event = json.loads(line[6:])
        kind = event.get('type')
        if kind == 'response.output_text.delta':
            value = event.get('delta', '')
            total += len(value.encode())
            if total > MAX_OUTPUT:
                raise Paused('出力上限で停止しました。')
            chunks.append(value)
        elif kind in ('response.failed', 'error', 'response.incomplete'):
            error = event.get('response', {}).get('error') or event.get('error') or event
            code = error.get('code', 'response_incomplete') if isinstance(error, dict) else 'unknown_error'
            raise Paused('利用枠を確認してください。' if code in LIMIT_CODES else 'AI処理が完了しませんでした。')
        elif kind == 'response.completed':
            completed = True
    if not completed:
        raise Paused('通信が途中で終了しました。自動で再送しません。')
    return ''.join(chunks)


def save_project(root, result):
    if result.startswith('```'):
        result = result.split('\n', 1)[1].rsplit('```', 1)[0]
    data = json.loads(result)
    files = data.get('files', [])
    if not isinstance(files, list) or len(files) > 30:
        raise ValueError('作成するファイル数が上限を超えました。')
    prepared = []
    for item in files:
        relative = Path(item['path'])
        if relative.is_absolute() or '..' in relative.parts or any(p.startswith('.') for p in relative.parts):
            raise ValueError('プロジェクト外への書き込みを拒否しました。')
        if relative.suffix.lower() not in {'.html', '.css', '.js', '.json', '.md', '.txt', '.svg'}:
            raise ValueError('対応しないファイル形式です。')
        target = (root / relative).resolve()
        if not target.is_relative_to(root.resolve()) or target == root.resolve():
            raise ValueError('書き込み先が不正です。')
        content = item['content']
        if not isinstance(content, str) or len(content.encode()) > MAX_FILE:
            raise ValueError('ファイル容量の上限です。')
        prepared.append((target, content))
    root.mkdir(parents=True, exist_ok=True)
    for target, content in prepared:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content)
    return str(data.get('summary', '試作品を作成しました。'))[:5000]


class Worker:
    def __init__(self, auth, sync, local):
        self.auth, self.sync, self.local = auth, Path(sync), Path(local)
        self.ledger_file = self.local / 'ledger.json'
        self.ledger = read_json(self.ledger_file) if self.ledger_file.exists() else {'jobs': {}, 'day': '', 'calls': 0, 'blocked': False}
        self.running = False
        self.model = ''

    def persist(self):
        atomic_json(self.ledger_file, self.ledger)

    def status(self, request, state, percent, message):
        atomic_json(self.sync / (request['id'] + '.status.json'), dict(
            id=request['id'], revision=request['revision'], state=state, percent=percent,
            message=message, updated=time.time()))

    def cancelled(self, request):
        if not self.running:
            return True
        current = read_json(self.sync / (request['id'] + '.request.json'))
        return current.get('action') != 'run' or current.get('revision') != request['revision']

    def tick(self):
        if not self.running or self.ledger['blocked']:
            return
        if queue_size(self.sync) > MAX_QUEUE:
            self.ledger['blocked'] = True
            self.persist()
            return
        for path in sorted(self.sync.glob('*.request.json')):
            request = read_json(path)
            identifier = str(uuid.UUID(request['id'])).upper()
            if request['id'] != identifier or path.name != identifier + '.request.json':
                continue
            revision = str(uuid.UUID(request['revision'])).upper()
            if request.get('action') != 'run' or not isinstance(request.get('text'), str) or len(request['text']) > 30000:
                continue
            key = identifier + ':' + revision
            if key in self.ledger['jobs']:
                continue
            day = time.strftime('%Y-%m-%d')
            if self.ledger['day'] != day:
                self.ledger.update(day=day, calls=0)
            if self.ledger['calls'] >= MAX_CALLS_PER_DAY:
                self.status(request, 'paused', 0, '1日の実行上限です。翌日以降に再開できます。')
                continue
            self.ledger['jobs'][key] = 'started'
            self.ledger['calls'] += 1
            self.persist()  # Reserve before network; a crash never repeats billed work.
            try:
                token = self.auth.token()
                if not self.model:
                    raise Paused('Macでモデルを選んでください。')
                self.status(request, 'running', 10, 'メモをもとに試作品を作っています。')
                instructions = ('メモから動作する静的Webアプリの試作品を作成。外部通信、CDN、課金、追跡は禁止。'
                                '説明だけでなくHTML/CSS/JSの実ファイルを作る。シェル実行・公開はしない。'
                                'JSONのみを返す: {"summary":"実装内容と未検証点","files":[{"path":"index.html","content":"..."}]}。'
                                '試作品であり、動作テスト未実施をsummaryに明示。')
                with requests.post(RESOURCE + '/responses', headers={'Authorization': 'Bearer ' + token},
                    json={'model': self.model, 'store': False, 'stream': True, 'instructions': instructions,
                          'input': [{'role': 'user', 'content': request['text']}]}, stream=True, timeout=(15, 45)) as response:
                    if response.status_code != 200:
                        raise Paused('利用枠または接続を確認してください。自動再試行は停止しました。')
                    result = consume_stream(response.iter_lines(decode_unicode=True), lambda: self.cancelled(request))
                if self.cancelled(request):
                    raise Paused('停止しました。')
                project = self.local / 'projects' / identifier / revision
                summary = save_project(project, result)
                self.status(request, 'review', 40, summary + '\nMacのprojectsフォルダに試作品を保存しました。動作確認・審査・公開は未完了です。')
                self.ledger['jobs'][key] = 'completed'
            except Exception as e:
                # Do not expose provider response bodies or tokens in shared files.
                message = str(e) if isinstance(e, (Paused, ValueError)) else '接続または保存に失敗しました。Macで確認してください。'
                self.ledger['jobs'][key] = 'paused'
                self.ledger['blocked'] = True
                self.running = False
                self.status(request, 'paused', 0, message)
            finally:
                self.persist()
            return
