import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'companion'))
from worker import consume_stream, Paused, save_project, Worker
from auth import atomic_json

class SafetyTests(unittest.TestCase):
    def test_partial_then_quota_never_succeeds(self):
        events = [{'type':'response.output_text.delta','delta':'partial'}, {'type':'response.failed','response':{'error':{'code':'subscription_sharing_usage_limit_exceeded'}}}]
        with self.assertRaises(Paused): consume_stream(['data: '+json.dumps(e) for e in events], lambda:False)
    def test_missing_completed_never_succeeds(self):
        with self.assertRaises(Paused):consume_stream(['data: {"type":"response.output_text.delta","delta":"x"}'],lambda:False)
    def test_pause_stops_stream(self):
        with self.assertRaises(Paused):consume_stream(['data: {"type":"response.completed"}'],lambda:True)
    def test_complete(self):
        self.assertEqual(consume_stream(['data: {"type":"response.output_text.delta","delta":"ok"}','data: {"type":"response.completed"}'],lambda:False),'ok')
    def test_project_traversal_and_symlink(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)/'project';root.mkdir()
            for path in ['../escape.html','/tmp/escape.html','.env','launch.command']:
                with self.assertRaises(ValueError):save_project(root,json.dumps({'files':[{'path':path,'content':'x'}]}))
            (root/'link').symlink_to(Path(directory),target_is_directory=True)
            with self.assertRaises(ValueError):save_project(root,json.dumps({'files':[{'path':'link/escape.html','content':'x'}]}))
    def test_credentials_are_private(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'credentials.json';atomic_json(path,{'test':True})
            self.assertEqual(path.stat().st_mode & 0o777,0o600)
    def test_crash_reservation_never_repeats_request(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);sync=root/'sync';sync.mkdir();local=root/'local';local.mkdir()
            rid='12345678-1234-4234-8234-123456789012';rev='12345678-1234-4234-8234-123456789013'
            atomic_json(sync/(rid+'.request.json'),dict(id=rid,revision=rev,action='run',text='test'))
            class Auth:
                def token(self):raise AssertionError('must not call')
            worker=Worker(Auth(),sync,local);worker.ledger['jobs'][rid+':'+rev]='started';worker.persist()
            restarted=Worker(Auth(),sync,local);restarted.running=True;restarted.tick()
            self.assertEqual(restarted.ledger['calls'],0)
    def test_daily_cap_no_network(self):
        import time
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);sync=root/'sync';sync.mkdir();local=root/'local';local.mkdir()
            rid='12345678-1234-4234-8234-123456789012';rev='12345678-1234-4234-8234-123456789013'
            atomic_json(sync/(rid+'.request.json'),dict(id=rid,revision=rev,action='run',text='test'))
            class Auth:
                def token(self):raise AssertionError('must not call')
            worker=Worker(Auth(),sync,local);worker.running=True;worker.ledger.update(day=time.strftime('%Y-%m-%d'),calls=3)
            worker.tick();self.assertEqual(json.loads((sync/(rid+'.status.json')).read_text())['state'],'paused')
if __name__=='__main__':unittest.main()
