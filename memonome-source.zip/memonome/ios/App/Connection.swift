import SwiftUI
import UniformTypeIdentifiers

struct DevelopmentStatus: Codable {
    let id: String
    let revision: String
    let state: String
    let percent: Int
    let message: String
    let updated: Double
    var isFresh: Bool { Date().timeIntervalSince1970 - updated < 120 }
}
struct DevelopmentRequest: Codable {
    let id: String
    let revision: String
    let text: String
    let action: String
}
@MainActor final class Connection: ObservableObject {
    @Published var folderName: String = "未接続"
    @Published var message: String?
    @Published var statuses: [UUID: DevelopmentStatus] = [:]
    @Published var requests: [UUID: DevelopmentRequest] = [:]
    private var folder: URL?
    private let maxBytes = 5_000_000
    init() {
        guard let data = UserDefaults.standard.data(forKey: "syncFolder") else { return }
        do {
            var stale = false
            let url = try URL(resolvingBookmarkData: data, options: [], relativeTo: nil, bookmarkDataIsStale: &stale)
            try connect(url)
        } catch { message = "同期フォルダを選び直してください。メモは端末に残っています。" }
    }
    func connect(_ url: URL) throws {
        guard url.startAccessingSecurityScopedResource() else { throw CocoaError(.fileReadNoPermission) }
        defer { url.stopAccessingSecurityScopedResource() }
        let data = try url.bookmarkData(options: .minimalBookmark, includingResourceValuesForKeys: nil, relativeTo: nil)
        UserDefaults.standard.set(data, forKey: "syncFolder")
        folder = url; folderName = url.lastPathComponent
    }
    func disconnect() {
        // Pausing all submitted requests must succeed before forgetting the folder.
        for request in requests.values where request.action == "run" {
            guard let id = UUID(uuidString: request.id) else { continue }
            do { try write(DevelopmentRequest(id: id.uuidString, revision: UUID().uuidString, text: "", action: "pause")) }
            catch { message = "停止を送れませんでした。Mac側でも停止してから解除してください。"; return }
        }
        folder = nil; folderName = "未接続"; requests = [:]; statuses = [:]
        UserDefaults.standard.removeObject(forKey: "syncFolder")
    }
    private func access<T>(_ operation: (URL) throws -> T) throws -> T {
        guard let folder, folder.startAccessingSecurityScopedResource() else { throw CocoaError(.fileReadNoPermission) }
        defer { folder.stopAccessingSecurityScopedResource() }
        return try operation(folder)
    }
    private func write(_ request: DevelopmentRequest) throws {
        try access { directory in
            let files = try FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: [.fileSizeKey, .isSymbolicLinkKey])
            var size = 0
            for file in files {
                let values = try file.resourceValues(forKeys: [.fileSizeKey, .isSymbolicLinkKey])
                if values.isSymbolicLink == true { throw CocoaError(.fileReadNoPermission) }
                size += values.fileSize ?? 0
            }
            let data = try JSONEncoder().encode(request)
            // Stop commands remain available when the mailbox is full.
            guard request.action == "pause" || size + data.count <= maxBytes else { throw CocoaError(.fileWriteOutOfSpace) }
            let target = directory.appendingPathComponent(request.id + ".request.json")
            var coordinationError: NSError?
            var writeError: Error?
            NSFileCoordinator().coordinate(writingItemAt: target, options: .forReplacing, error: &coordinationError) { url in
                do { try data.write(to: url, options: .atomic) } catch { writeError = error }
            }
            if let error = coordinationError ?? writeError as NSError? { throw error }
            requests[UUID(uuidString: request.id)!] = request
        }
    }
    func submit(_ memo: Memo, run: Bool) {
        guard memo.text.count <= 30000 else { message = "自動処理は3万文字以内のメモに対応しています。"; return }
        do {
            try write(DevelopmentRequest(id: memo.id.uuidString, revision: UUID().uuidString, text: run ? memo.text : "", action: run ? "run" : "pause"))
            message = run ? "同期フォルダに保存しました。Macへの到着まで時間がかかることがあります。" : "停止を依頼しました。Macへの到着後に停止します。"
        } catch { message = "同期できませんでした。フォルダの権限・空き容量・ネット接続を確認してください。メモは端末に残っています。" }
    }
    func refresh() {
        do {
            try access { directory in
                let files = try FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: [.fileSizeKey, .isSymbolicLinkKey])
                var next: [UUID: DevelopmentStatus] = [:]
                var pending: [UUID: DevelopmentRequest] = [:]
                for file in files where file.lastPathComponent.hasSuffix(".json") {
                    let values = try file.resourceValues(forKeys: [.fileSizeKey, .isSymbolicLinkKey])
                    guard values.isSymbolicLink != true, (values.fileSize ?? 0) <= 300000 else { continue }
                    var data: Data?
                    var err: NSError?
                    NSFileCoordinator().coordinate(readingItemAt: file, options: [], error: &err) { data = try? Data(contentsOf: $0) }
                    guard let data else { continue }
                    if file.lastPathComponent.hasSuffix(".status.json"), let status = try? JSONDecoder().decode(DevelopmentStatus.self, from: data), let id = UUID(uuidString: status.id) { next[id] = status }
                    if file.lastPathComponent.hasSuffix(".request.json"), let request = try? JSONDecoder().decode(DevelopmentRequest.self, from: data), let id = UUID(uuidString: request.id) { pending[id] = request }
                }
                statuses = next; requests = pending
            }
        } catch { /* Offline notes remain usable; last known progress is marked stale. */ }
    }
}
struct ConnectionSettings: View {
    @EnvironmentObject private var connection: Connection
    @State private var choose = false
    var body: some View {
        Form {
            Section("自分のMacとつなぐ") {
                Text("ChatGPTへのログインはMacで行います。iPhoneとMacで、同じ自分専用のiCloud Driveフォルダを選んでください。")
                Text("同期フォルダ：\(connection.folderName)")
                Button("同期フォルダを選ぶ") { choose = true }
                Button("接続を解除", role: .destructive) { connection.disconnect() }
            }
            Section("送信する内容") { Text("AIにおまかせを押したメモだけを同期フォルダへ保存します。Macが読み取り、OpenAIへ送信します。認証情報はMacに保存し、このフォルダへは送りません。ほかの人と共有しているフォルダは選ばないでください。") }
            Section("追加料金を使わない") {
                Text("有料APIへの切り替え・容量購入・クレジット購入は行いません。MacでChatGPTの追加クレジット使用をオフにしたことを確認してから開始します。1日3回、同期データ5MBが上限です。")
                Text("容量不足や同期の遅延は端末から検出できないことがあります。Macがオフラインの場合も待機します。メモ自体は端末内で使えます。")
            }
            Section("開発版について") { Text("現在は静的Webアプリの試作品まで作ります。動作確認・App Store向けのアプリ化・審査提出・公開は別途必要です。40%は試作品作成の目安で、公開完了は100%です。") }
        }.navigationTitle("ChatGPT・Mac連携")
            .fileImporter(isPresented: $choose, allowedContentTypes: [.folder]) { result in
                do { try connection.connect(result.get()) } catch { connection.message = "フォルダに接続できませんでした。" }
            }
    }
}
struct DevelopmentPanel: View {
    let memo: Memo
    @EnvironmentObject private var connection: Connection
    @State private var confirm = false
    var body: some View {
        Section("AIにおまかせ · 開発版") {
            if let status = connection.statuses[memo.id] {
                Text("\(min(100, max(0, status.percent)))% · \(status.state == "running" && status.isFresh ? "開発中" : status.state == "review" ? "試作品の確認待ち" : "停止中・接続確認")").font(.headline)
                Text(status.message).font(.subheadline).textSelection(.enabled)
            }
            if connection.requests[memo.id]?.revision != connection.statuses[memo.id]?.revision {
                Text("Macへの到着・反映待ち").font(.caption).foregroundStyle(.secondary)
            }
            Button("AIにおまかせ・再開") { confirm = true }
            Button("開発の停止を依頼") { connection.submit(memo, run: false) }
            Text("本人のChatGPT利用枠を使用。Macが起動し、接続済みである必要があります。").font(.caption).foregroundStyle(.secondary)
        }.confirmationDialog("このメモをMacとOpenAIへ送って、試作品を作りますか？", isPresented: $confirm, titleVisibility: .visible) {
            Button("このメモで開始") { connection.submit(memo, run: true) }
            Button("キャンセル", role: .cancel) {}
        }
    }
}
